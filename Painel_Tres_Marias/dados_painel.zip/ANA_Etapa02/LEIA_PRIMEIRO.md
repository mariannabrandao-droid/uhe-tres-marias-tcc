# Etapa ANA 02
As entradas e os resultados desta pasta sustentam as séries de chuva e vazão, as análises climáticas e o inventário de cobertura do painel.

## Reprodução
Python com pandas e numpy. Em uma cópia sem resultados existentes:

    python selecionar_limpar.py
    python integrar_clima.py

O segundo comando depende do primeiro. Preserve a pasta resultados original antes de reexecutar. As entradas já são tabelas longas da etapa 01; os CSVs brutos permanecem no pacote daquela etapa. Incluímos a auditoria anterior e a base operacional diária recebida para rastreabilidade.

## Arquivos centrais
01_decisao_45_estacoes.csv: destinação de todo o universo inicial.
02_qualidade_e_cobertura.csv: efeito dos filtros e cobertura.
03_matriz_historica_postos.csv: calendário de quatro postos, sem índices atmosféricos.
04_sar_mensal_cobertura_por_variavel.csv: operação do reservatório com cobertura independente.
05_matriz_recente_reservatorio_chuva_pontual.csv: operação mais chuva pontual recente.
06_base_modelo_AR_Ridge_Persistencia.csv: atributos e etiquetas para previsão. Nunca usar colunas alvo como preditores.
07_confronto_barramento_SAR.csv: comparação que NÃO atribui identidade física.
08_resumo_decisoes.json: contagens de controle.
09_historico_limpeza.csv e 10_manifesto_sha256.csv: trilha de processamento.
11_indices_climaticos_mensais.csv: médias ZCAS e dias de bloqueio em meses completos.
12_matriz_historica_datamining.csv: quatro postos e clima, 182 meses completos de 183.
13_matriz_recente_datamining.csv: janela recente, com ausências preservadas; 47 meses multivariados completos.
14_jusante_clima_historico.csv: 508 meses multivariados completos de 538.
15_indaia_clima_historico.csv: 287 meses multivariados completos.

Colunas valor_parcial são resumos incompletos. Usar valor_analise para as análises mensais principais. Ausências não são zero. Não houve imputação nem retraining de modelos. O corte 100% é escolha conservadora do projeto, não norma universal.
