from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
R=Path(__file__).resolve().parent/'resultados'
d=pd.read_csv(R/'01_decisao_45_estacoes.csv',sep=';',dtype={'codigo':str});codes=['01845032','01845009','01944060','41020002','40963000','41020003','01845001'];s=d[d.codigo.isin(codes)]
fig,axes=plt.subplots(1,2,figsize=(13,6.5));fig.suptitle('Localização cadastral dos postos por finalidade',fontsize=14)
for j,ax in enumerate(axes):
 for _,x in s.iterrows():
  shared=x.codigo=='01845009';color='#1678A5' if x.codigo.startswith('0') else '#B05020'
  if shared:ax.scatter(x.longitude,x.latitude,c='#B05020',s=100,zorder=3);ax.scatter(x.longitude,x.latitude,c='#1678A5',s=28,zorder=4)
  else:ax.scatter(x.longitude,x.latitude,c=color,s=45,zorder=3)
  if j==0:
   if x.codigo in ['01845009','41020002','41020003']:continue
   label=x.codigo;offset=(6,6)
  else:
   if x.codigo not in ['01845001','01845009','41020002','41020003']:continue
   label='01845009 / 40990080' if shared else x.codigo
   offset={'01845001':(8,4),'01845009':(-75,-22),'41020002':(10,-4),'41020003':(-12,15)}[x.codigo]
  ax.annotate(label,(x.longitude,x.latitude),xytext=offset,textcoords='offset points',fontsize=9)
 ax.set_xlabel('Longitude cadastral (graus)');ax.set_ylabel('Latitude cadastral (graus)');ax.grid(alpha=.2);ax.xaxis.set_major_locator(MaxNLocator(4));ax.yaxis.set_major_locator(MaxNLocator(5))
axes[0].set_xlim(-45.75,-44.45);axes[0].set_ylim(-19.3,-17.95);axes[0].set_title('Distribuição regional');axes[0].annotate('Postos próximos ao barramento\n(ver ampliação)',(-45.26,-18.20),xytext=(-45.69,-18.43),arrowprops={'arrowstyle':'->','color':'gray'},fontsize=9)
axes[1].set_xlim(-45.31,-45.17);axes[1].set_ylim(-18.25,-18.055);axes[1].set_title('Ampliação próxima ao barramento')
fig.text(.5,.025,'Azul: chuva. Laranja: cota/vazão. Dois códigos compartilham o ponto do barramento.\nFonte: inventário ANA. Sem delimitação da bacia ou drenagem; datum não confirmado.',ha='center',fontsize=9)
fig.tight_layout(rect=[0,.09,1,.94]);fig.savefig(R/'16_localizacao_cadastral.png',dpi=180)
