"""Integra índices fornecidos; não reconstrói a detecção original de ZCAS."""
from pathlib import Path
import pandas as pd
R=Path(__file__).resolve().parent;S=R/'entradas';O=R/'resultados'
z=pd.read_csv(S/'zcas_diario_fornecido.csv',parse_dates=['time']).set_index('time');assert not z.index.duplicated().any();zm=pd.DataFrame(index=z.resample('MS').size().index)
for col in ['SACZ_AB','SACZ_C','SACZ_DE']:
 n=z[col].resample('MS').count();zm[col]=z[col].resample('MS').mean().where(n.eq(n.index.days_in_month));zm[col+'_cobertura']=n/n.index.days_in_month
b=pd.read_csv(S/'bloqueio_total_campos.csv',sep=';',decimal=',',parse_dates=['time']).set_index('time').sort_index();assert not b.index.duplicated().any()
b=b.reindex(pd.date_range(b.index.min(),b.index.max(),freq='D'));fields=['an_geop500','vort850','vort500'];available=b[fields].notna().all(axis=1);flag=b[fields].gt(0).all(axis=1)&available;group=flag.ne(flag.shift()).cumsum();event=flag&flag.groupby(group).transform('size').ge(3)
n=available.astype(int).resample('MS').sum();zm['dias_bloqueio_total']=event.astype(int).resample('MS').sum().where(n.eq(n.index.days_in_month));zm['bloqueio_cobertura']=n/n.index.days_in_month
zm.index.name='data';zm.to_csv(O/'11_indices_climaticos_mensais.csv',sep=';',encoding='utf-8-sig')
for infile,outfile in [('03_matriz_historica_postos.csv','12_matriz_historica_datamining.csv'),('05_matriz_recente_reservatorio_chuva_pontual.csv','13_matriz_recente_datamining.csv')]:
 x=pd.read_csv(O/infile,sep=';',parse_dates=['data']).set_index('data');x=x.drop(columns=['pares_completos'],errors='ignore');j=x.join(zm[['SACZ_AB','SACZ_C','SACZ_DE','dias_bloqueio_total']]);j.to_csv(O/outfile,sep=';',encoding='utf-8-sig')
 print(outfile,'meses',len(j),'completos todas variáveis',j.drop(columns=[c for c in j if c.endswith('_cobertura')],errors='ignore').notna().all(axis=1).sum())
for code,start,end,outfile in [('41020002','1962-01-01','2006-10-01','14_jusante_clima_historico.csv'),('40963000','1978-01-01','2001-11-01','15_indaia_clima_historico.csv')]:
 q=pd.read_csv(O/'mensal'/f'{code}_Vazoes.csv',sep=';',parse_dates=['data']).set_index('data').loc[start:end]
 x=q[['valor_analise','cobertura']].rename(columns={'valor_analise':'vazao_m3s'}).join(zm[['SACZ_AB','SACZ_C','SACZ_DE','dias_bloqueio_total']]);x.to_csv(O/outfile,sep=';',encoding='utf-8-sig')
 print(outfile,'meses',len(x),'completos',x.drop(columns='cobertura').notna().all(axis=1).sum())
