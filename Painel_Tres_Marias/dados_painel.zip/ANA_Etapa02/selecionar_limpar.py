"""Limpeza conservadora e bases por finalidade. Uso no pacote: python selecionar_limpar.py
Não baixa dados nem preenche falhas. Requer pandas e numpy.
"""
from pathlib import Path
import json,math,hashlib,shutil
import pandas as pd
import numpy as np
ROOT=Path(__file__).resolve().parent
SRC=ROOT/'entradas';OUT=ROOT/'resultados'
if OUT.exists() and any(OUT.iterdir()):raise SystemExit('Preserve resultados existentes; escolha uma nova cópia do projeto para reexecutar.')
OUT.mkdir(exist_ok=True);(OUT/'diario').mkdir();(OUT/'mensal').mkdir()
A=json.loads((SRC/'auditoria_anterior.json').read_text());metadata={s['codigo']:s for s in A['stations']}
choices={
'01845032':('Chuva pontual recente','Principal','Não é chuva média da bacia nem entrada atual do Ridge.'),
'01845009':('Chuva pontual histórica no barramento','Principal histórica','Manter separada de Andrequice; sem concatenação entre postos.'),
'01944060':('Chuva pontual histórica Porto Mesquita','Comparação histórica','Distância maior não exclui por si só; não representa toda a bacia.'),
'41020002':('Vazão histórica no controle de jusante','Principal histórica','Não usar como vazão natural nem concatenar ao SAR. Período anterior à operação separado.'),
'40963000':('Vazão do rio Indaiá','Complementar histórica','Contribuição de uma sub-bacia; não é afluência total. Não somar a postos aninhados.'),
'40990080':('Cota do barramento e vazão para confronto','Comparação cadastral','Vazão tem forte proximidade à afluência SAR no período comum; tipo físico ainda não confirmado. Não é fonte de defluência adotada.'),
'41020003':('Cota histórica','Arquivo auxiliar','Horários e datum distintos; não entra na matriz multivariada principal.'),
'01845001':('Chuva histórica antiga','Arquivo auxiliar','1958–1961, sem sobreposição com demais pluviômetros; coordenada difere do barramento recente.')}
def dist(s):
 la,lb=map(math.radians,[s['latitude'],-18.215]);dl=math.radians(s['longitude']+45.2592)
 return 6371*2*math.asin(math.sqrt(math.sin((la-lb)/2)**2+math.cos(la)*math.cos(lb)*math.sin(dl/2)**2))
selection=[]
for s in A['stations']:
 code=s['codigo'];role,use,limit=choices.get(code,('Informação auxiliar' if s['qtd_csv'] else 'Sem CSV','Fora das matrizes principais','Preservar inventário e origem.'))
 if s['triagem']!='São Francisco em MG; conferir posição':use='Fora do recorte principal';limit=s['observacoes_texto']
 selection.append({'codigo':code,'nome':s['nome'],'latitude':s['latitude'],'longitude':s['longitude'],'distancia_barramento_km':round(dist(s),2),'dados':s['dados_texto'],'uso':use,'funcao':role,'limite':limit,'verificacao_espacial':'Coordenadas cadastrais e função; sem teste GIS ponto em polígono','datum':'Não confirmado'})
pd.DataFrame(selection).to_csv(OUT/'01_decisao_45_estacoes.csv',sep=';',index=False,encoding='utf-8-sig')
settings=[('01845032','Chuvas'),('01845009','Chuvas'),('01944060','Chuvas'),('41020002','Vazoes'),('40963000','Vazoes'),('40990080','Vazoes'),('40990080','Cotas')]
actions=[];monthlies={};quality=[]
for code,kind in settings:
 f=next((SRC/'series_diarias').glob(f'{code.lstrip("0")}_{kind}_longo.csv'))
 raw=pd.read_csv(f,sep=';',dtype={'codigo':str,'nivel_consistencia':str,'status':str,'hora':str,'media_diaria':str,'parametro_clima':str},parse_dates=['data'])
 raw['valor']=pd.to_numeric(raw.valor,errors='coerce')
 admiss=raw.valor.notna() & raw.status.eq('1')
 if kind in ['Chuvas','Vazoes']:admiss &=raw.valor.ge(0)
 if kind in ['Vazoes','Cotas']:admiss &=raw.media_diaria.eq('1')
 # Duas versões no mesmo dia não são duas observações físicas.
 valid=raw.loc[admiss].copy();valid['prioridade']=pd.to_numeric(valid.nivel_consistencia,errors='coerce').fillna(-1)
 conflicts=valid.groupby(['data','nivel_consistencia']).valor.nunique();bad=set(conflicts[conflicts>1].index.get_level_values(0))
 valid=valid[~valid.data.isin(bad)].sort_values(['data','prioridade','linha_registro'],ascending=[True,False,True])
 leveldis=valid.groupby('data').valor.nunique().gt(1)
 best=valid.drop_duplicates('data').set_index('data')
 idx=pd.date_range(raw.data.min(),raw.data.max(),freq='D');d=best.reindex(idx);d.index.name='data'
 d['codigo']=code;d['tipo']=kind;d['observacao_admitida']=d.valor.notna();d['divergencia_entre_niveis']=leveldis.reindex(idx,fill_value=False).astype(bool)
 d['conflito_mesmo_nivel']=idx.isin(bad)
 d['motivo_ausencia']=np.where(d.valor.notna(),'','Sem registro admissível: ausente/status excluído/conflito')
 d[['codigo','tipo','valor','nivel_consistencia','status','observacao_admitida','divergencia_entre_niveis','conflito_mesmo_nivel','arquivo_origem','linha_registro','motivo_ausencia']].to_csv(OUT/'diario'/f'{code}_{kind}.csv',sep=';',encoding='utf-8-sig')
 g=d.valor.resample('MS');m=pd.DataFrame({'dias_admitidos':g.count(),'dias_mes':g.count().index.days_in_month});m['cobertura']=m.dias_admitidos/m.dias_mes;m['mes_completo']=m.dias_admitidos.eq(m.dias_mes)
 m['valor_parcial']=g.sum(min_count=1) if kind=='Chuvas' else g.mean();m['valor_analise']=m.valor_parcial.where(m.mes_completo);m['codigo']=code;m['tipo']=kind
 m['n_dias_nivel2']=d.nivel_consistencia.eq('2').resample('MS').sum();m['n_dias_nivel1']=d.nivel_consistencia.eq('1').resample('MS').sum();m.index.name='data'
 m.to_csv(OUT/'mensal'/f'{code}_{kind}.csv',sep=';',encoding='utf-8-sig');monthlies[(code,kind)]=m
 quality.append({'codigo':code,'tipo':kind,'linhas_origem':len(raw),'dias_calendario':len(d),'dias_admitidos':int(d.valor.count()),'dias_divergencia_niveis':int(d.divergencia_entre_niveis.sum()),'dias_conflito_mesmo_nivel':len(bad),'meses_calendario':len(m),'meses_completos':int(m.mes_completo.sum()),'primeiro_mes_completo':str(m.index[m.mes_completo].min().date()),'ultimo_mes_completo':str(m.index[m.mes_completo].max().date())})
 actions.append({'acao':'Limpeza '+code+' '+kind,'regra':'Status 1; nível 2 preferido ao 1; média diária para vazão/cota; sem imputação','produto':str(OUT/'mensal'/f'{code}_{kind}.csv')})
pd.DataFrame(quality).to_csv(OUT/'02_qualidade_e_cobertura.csv',sep=';',index=False,encoding='utf-8-sig')
# Matrizes com todos os meses da janela; ausências não são comprimidas nem zero.
def matrix(start,end,cols,name):
 idx=pd.date_range(start,end,freq='MS');frame=pd.DataFrame(index=idx)
 for column,key in cols.items():frame[column]=monthlies[key].valor_analise.reindex(idx)
 frame['pares_completos']=frame.notna().all(axis=1);frame.index.name='data';frame.to_csv(OUT/name,sep=';',encoding='utf-8-sig');return frame
hist=matrix('1978-01-01','1993-03-01',{'chuva_barramento_mm':('01845009','Chuvas'),'chuva_mesquita_mm':('01944060','Chuvas'),'vazao_jusante_m3s':('41020002','Vazoes'),'vazao_indaia_m3s':('40963000','Vazoes')},'03_matriz_historica_postos.csv')
# SAR: completude independente por variável e média mensal conservadora.
sar=pd.read_csv(SRC/'sar_diario.csv',parse_dates=['data']).set_index('data').sort_index();assert not sar.index.duplicated().any()
sar=sar.reindex(pd.date_range(sar.index.min(),sar.index.max(),freq='D'));sar.index.name='data';sar.to_csv(OUT/'diario/SAR_reservatorio.csv',sep=';',encoding='utf-8-sig')
sm=pd.DataFrame(index=pd.date_range(sar.index.min().replace(day=1),sar.index.max().replace(day=1),freq='MS'))
for col in sar.columns:
 count=sar[col].resample('MS').count();sm[col]=sar[col].resample('MS').mean().where(count.eq(count.index.days_in_month));sm[col+'_cobertura']=count/count.index.days_in_month
sm.index.name='data';sm.to_csv(OUT/'04_sar_mensal_cobertura_por_variavel.csv',sep=';',encoding='utf-8-sig')
recent=sm.copy();recent['chuva_andrequice_mm']=monthlies[('01845032','Chuvas')].valor_analise.reindex(recent.index);recent.to_csv(OUT/'05_matriz_recente_reservatorio_chuva_pontual.csv',sep=';',encoding='utf-8-sig')
q=sm.vazao_natural_m3s;pred=pd.DataFrame(index=q.index);pred['vazao_natural_m3s']=q
for lag in [0,1,2,3,6,12]:pred['q_lag'+str(lag)]=q.shift(lag)
for h in [1,2]:
 target=pred.index+pd.DateOffset(months=h);pred[f'alvo_M{h}']=q.shift(-h);pred[f'data_alvo_M{h}']=target;pred[f'seno_M{h}']=np.sin(2*np.pi*target.month/12);pred[f'cosseno_M{h}']=np.cos(2*np.pi*target.month/12)
pred['atributos_disponiveis']=pred[[f'q_lag{x}' for x in [0,1,2,3,6,12]]].notna().all(axis=1);pred.index.name='origem';pred.to_csv(OUT/'06_base_modelo_AR_Ridge_Persistencia.csv',sep=';',encoding='utf-8-sig')
# Teste de identidade aproximada: comparação não é certificação de natureza física.
p=pd.read_csv(OUT/'diario/40990080_Vazoes.csv',sep=';',parse_dates=['data']).set_index('data').valor
j=sar.join(p.rename('posto')).dropna(subset=['posto']);comp=[]
for col in ['afluencia_m3s','defluencia_m3s','vazao_natural_m3s']:
 z=j[['posto',col]].dropna();comp.append({'serie_sar':col,'n_dias':len(z),'MAE_m3s':float((z.posto-z[col]).abs().mean()),'pearson':float(z.posto.corr(z[col])),'conclusao':'Comparação empírica; não atribui identidade física ao posto'})
pd.DataFrame(comp).to_csv(OUT/'07_confronto_barramento_SAR.csv',sep=';',index=False,encoding='utf-8-sig')
summary={'historico_inicio':'1978-01-01','historico_fim':'1993-03-01','historico_meses':len(hist),'historico_meses_quatro_postos_completos':int(hist.pares_completos.sum()),'sar_meses':len(sm),'sar_natural_meses_completos':int(sm.vazao_natural_m3s.count()),'recente_meses_chuva_natural_completos':int(recent[['vazao_natural_m3s','chuva_andrequice_mm']].notna().all(axis=1).sum()),'fim_natural_completo':str(q.dropna().index.max().date()),'fim_chuva_analise':str(monthlies[('01845032','Chuvas')].index[monthlies[('01845032','Chuvas')].mes_completo].max().date())}
(OUT/'08_resumo_decisoes.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf8')
pd.DataFrame(actions).to_csv(OUT/'09_historico_limpeza.csv',sep=';',index=False,encoding='utf-8-sig')
manifest=[{'arquivo':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(ROOT.rglob('*')) if p.is_file() and p.name!='10_manifesto_sha256.csv']
pd.DataFrame(manifest).to_csv(OUT/'10_manifesto_sha256.csv',sep=';',index=False,encoding='utf-8-sig')
print(pd.DataFrame(quality).to_string(index=False));print(json.dumps(summary,ensure_ascii=False,indent=2))
