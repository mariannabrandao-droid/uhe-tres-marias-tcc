# Fontes cartográficas

As duas camadas foram baixadas em 11/11/2026. Os mapas renderizam os arquivos locais e dispensam um serviço externo de mapas durante a apresentação. Os eixos mostram longitude e latitude em graus. A proporção dos eixos é ajustada para a latitude de Três Marias, adequada à leitura visual.

- `regiao_sao_francisco.geojson` — [Divisão hidrográfica ANA/SNIRH, camada 4](https://portal1.snirh.gov.br/arcgis/rest/services/SNIRH2016/Limites_hidrograficos_mapabase/MapServer/4). Consulta GeoJSON em EPSG:4326 com `UPPER(RHI_NM) LIKE '%FRANCISCO%'` e tolerância de generalização de 0,007°. Um polígono da Região Hidrográfica São Francisco. A camada representa a região hidrográfica, enquanto a área de contribuição específica da UHE exigiria delimitação própria.
- `hidrografia_tramo.geojson` — [Hidrografia ANA/SNIRH, camada 0](https://portal1.snirh.gov.br/server/rest/services/dados_abertos/Hidrografia/MapServer/0). Consulta por envelope (-45,32°, -18,27°, -45,18°, -18,13°) em EPSG:4326, tolerância 0,0002°. Seis trechos que interceptam a janela. Traçado generalizado para leitura.
- Marcadores — `ANA_Etapa02/resultados/01_decisao_45_estacoes.csv`, coordenadas cadastrais. O posto 01845009 referencia a área do Barramento. O código 41020002 identifica a estação de jusante indicada no texto da Resolução ANA nº 2.081/2017. A posição cadastral é aproximada e o datum dos pontos permanece pendente de confirmação.

Para interpretar os mapas e a análise, consulte o [monitoramento da ANA](https://www.gov.br/ana/pt-br/monitoramento), o [pedido divulgado pelo MPF](https://www.mpf.mp.br/o-mpf/unidades/pr-mg/noticias/mpf-ajuiza-acao-para-garantir-vazao-minima-do-rio-sao-francisco-em-tres-marias-mg) e a [base horária do ONS](https://dados.ons.org.br/dataset/dados_hidrologicos_ho).

- `logo_uff.png` — arquivo oficial fornecido pela autora para identificação institucional.
