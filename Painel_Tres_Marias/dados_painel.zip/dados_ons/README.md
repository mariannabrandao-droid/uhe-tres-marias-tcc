# Recorte ONS de outubro de 2026

Extração em 11/11/2026. Filtro id_reservatorio = SFTMAR, outubro de 2026. Os dois CSVs guardam os campos utilizados e os horários tal como registrados pela fonte. A extração diária retém também a vazão natural de outubro para rastreabilidade. O painel usa a série SAR auditada no histórico mensal e preserva a série natural do ONS como fonte distinta.

- [Base diária e dicionário](https://dados.ons.org.br/dataset/dados-hidrologicos-res)
- [Base horária e dicionário](https://dados.ons.org.br/dataset/dados_hidrologicos_ho)
- [CSV diário de 2026](https://ons-aws-prod-opendata.s3.amazonaws.com/dataset/dados_hidrologicos_di/DADOS_HIDROLOGICOS_RES_2026.csv)
- [CSV horário de outubro](https://ons-aws-prod-opendata.s3.amazonaws.com/dataset/dados_hidrologicos_ho/DADOS_HIDROLOGICOS_HO_2026_10.csv)
- [Notícia do MPF sobre a ação](https://www.mpf.mp.br/o-mpf/unidades/pr-mg/noticias/mpf-ajuiza-acao-para-garantir-vazao-minima-do-rio-sao-francisco-em-tres-marias-mg)
- [Resolução ANA nº 2.081/2017](https://www.gov.br/ana/pt-br/legislacao/resolucoes/resolucoes-regulatorias/2017/2081)

O horário do ONS representa o fim do intervalo. A janela [06h, 18h) contém as horas-fim 07h a 18h. Os 31 valores 23:59 são tratados como o último intervalo de cada dia. Só são comparados dias com os 12 intervalos diurnos válidos e a média diária oficial. A diferença de classificação ocorre quando a média diária é maior ou igual ao limiar e pelo menos um valor horário diurno é estritamente menor. A análise é exploratória e de resolução horária.

## Conferência direta dos arquivos oficiais

Baixe os dois CSVs originais pelos links acima. Na pasta do painel, execute `python auditar_ons.py CAMINHO_CSV_DIARIO CAMINHO_CSV_HORARIO`. O script compara o recorte local aos campos originais, conta os casos por horas-fim e registra SHA-256 dos arquivos. O painel roda com os recortes locais.

A 300 m³/s, as datas com média diária no patamar ou acima e algum intervalo abaixo são 22–26 e 29–31/10. Em 22/10 o mínimo de 164 m³/s está no intervalo 13h–14h (hora-fim 14h), frente a uma média diária de 450 m³/s. Os registros horários permitem uma triagem. Uma avaliação de conformidade requer o critério aplicável e informações no ponto e na resolução pertinentes.

A reexecução encontrou 18 dias com vazão natural em comum entre SAR e ONS, todos com diferença numérica e diferença absoluta máxima de 58,85 m³/s. As séries foram mantidas separadas. O hash do CSV diário anual pode mudar por novas publicações ou revisões. A conferência exige coincidência no recorte e nos campos usados, não do hash do arquivo anual inteiro.
