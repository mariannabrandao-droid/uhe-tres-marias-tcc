# Correspondência com o TCC

A navegação mantém as sete páginas identificadas no Quadro 3. Na página 01, a discussão do MPF abre a exposição, seguida do histórico da implantação e da localização da bacia. Na página 02, a leitura começa pelos postos.

| Página | Elementos do TCC | Fundamentação |
| --- | --- | --- |
| 00 · Capa e roteiro | Título e percurso | Quadro 3, seção 5.9 |
| 01 · Usina, operação e vazão mínima | Figuras 2, 3 e 10 | Introdução e seções 4.1, 4.5, 4.6 e 5.3 |
| 02 · Histórico, ZCAS e bloqueios | Figura 12 (postos); 1, 4, 9 e 13 (histórico); 5, 6, 7, 8 e 14 (clima); 15, 16 e 17 (previsão). Tabelas 1 e 2 | Seções 5.4 a 5.7 e 6.1 a 6.3 |
| 03 · Operação diária da usina | Figura 18 e estudo documental ONS | Seções 5.7 a 5.9, 6.3 e 6.4 |
| 04 · Defluência diária e horária | Figuras 11 e 19, Tabela 3 | Seções 4.6, 5.8 e 6.4 a 6.5 |
| 05 · Síntese e rastreabilidade | Fontes, inventário, dados de Pirapora | Quadro 3, seções 5.4 e 6.5 |
| 06 · Conclusão | Síntese do Quadro 4 | Capítulo 7 |

As 19 figuras numeradas reproduzem as visualizações do PDF indicado em `assets/figuras_pdf/manifesto.json`. O arquivo registra a página física do PDF e sua impressão SHA-256. As Figuras 2 e 3 mantêm as atribuições apresentadas no rascunho. Na seção 6.4, a chamada textual “Figura 20” aponta para o gráfico cuja legenda é **Figura 19**. A interface segue o número da legenda.

As análises numeradas usam os recortes do TCC. As tabelas e gráficos interativos usam os CSVs locais incluídos no ZIP. A importação da estação 41020002 tem finalidade exploratória e segue a seção 5.8. A consulta ao índice de boletins é complementar e não altera as séries do estudo.
