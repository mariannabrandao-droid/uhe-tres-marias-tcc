# Figuras e previsão experimental

Base do aplicativo: ZIP Painel_Operacao_Tres_Marias_UFF (3)(1). Referência de navegação e apresentação do
backtest: V3, commit 8a9a8191cdd6a713a98dfcf94b65bf29b4ee8dba do repositório mariannabrandao-droid/uhe-tres-marias-tcc.
Numeração e material gráfico: Marianna Brandão_Rascunho (1).docx, versão comentada.

- Figuras 1 e 4: planilha do acervo identificada como Três Marias (156), folha Planilha1. A série anual da coluna jan–dez
  coincide com a média das doze vazões mensais de cada ano, dentro do arredondamento da planilha. A Figura 1 agrupa o mesmo
  mês do calendário nas janelas terminadas em 2023. A origem institucional da planilha permanece por confirmar.
- Figura 2: mapa de localização redesenhado com a divisão hidrográfica e o cadastro ANA/SNIRH.
  Mostra o limite da região e a posição do Barramento. As classes de densidade demográfica
  e os limites das sub-regiões da imagem do Word não foram reproduzidos pela camada disponível.
- Figura 3: diagrama vetorial com os aproveitamentos, as duas rotas do complexo Paulo Afonso e
  os valores de potência e volume da figura histórica atribuída à ANA (2013) no Word.
- Figura 5: 63 pares aproximados digitalizados da Figura 4, p. 5, de Treistman et al. (2015),
  https://files.abrhidro.org.br/Eventos/Trabalhos/4/PAP019701.pdf. Procedimento: extração do gráfico
  raster de 991 × 536 px do PDF, calibração horizontal entre 1943 e 2005 (x = 20 a 977 px) e vertical
  entre 0 e 2,5 (y = 505 a 8 px). Em cada ano, foi lido o ponto pela cor na coluna central ou adjacente.
  A estimativa de vazão em 2005 foi lida visualmente junto à borda. Os pontos foram arredondados a
  duas casas e estão em `assets/tcc/treistman_fig4_digitizada.csv`. O artigo informa r = 0,75 para os dados
  originais. A série digitalizada serve à visualização histórica da publicação.
- Quadros 1 e 2: síntese em tabelas de texto com as linhas de pesquisa, métodos e limites para o estudo.
- Figura 6: índice diário por região AB, C ou DE. Média mensal de dias completos e média anual dos doze meses. As médias móveis
  usam os três ou cinco anos terminados no ano exibido e requerem que todos existam. Regiões de referência: Cataldi et al. (2025),
  seção 2.2 e tabela 2. DOI 10.3390/atmos16060699. Um índice contínuo requer regra adicional para virar contagem de eventos.
- Figura 7: média dos dias em que o critério implementado sinalizou bloqueio, por mês do calendário, de 1961 a 2023.
  A associação ZCAS × bloqueios mantém outubro a março em ambos os meses do par, inclusive com defasagem.
- NOAA/CPC: cópia de https://www.cpc.ncep.noaa.gov/data/indices/oni.ascii.txt obtida em 15/11/2026. A coluna ANOM é exibida
  em °C no mês central. A série é contextual. As saídas do Ridge usam somente vazão mensal defasada e sazonalidade.
- Ridge: referência de previsão mensal local em Paiva, Montenegro e Cataldi (2020), DOI 10.1590/2318-0331.252020190067.
  O trabalho de referência usa CFS, e o modelo experimental deste painel usa outra configuração de preditores.
  A auditoria usou os mesmos 21 meses-alvo por horizonte (jan/2025–set/2026). MAE M+1: persistência 247,76,
  climatologia 200,35 e Ridge 220,86 m³/s. MAE M+2: 405,55, 200,35 e 338,17 m³/s, respectivamente.
- ONS: as páginas operativas conservam a distinção das bases diária e horária. Os totais de 29/30 e 8/31 dias
  elegíveis nos dois outubros são avaliados no reservatório. A verificação no posto 41020002 continua pendente.

## Verificação pontual de outubro de 2026

No bloco de previsão experimental, as estimativas M+1 arquivadas (corte em setembro, emissão em 11/11/2026)
são comparadas à média de outubro dos 31 valores diários de vazão natural do ONS (SFTMAR, campo
`val_vazaonatural`). Na cópia local, a média é 292,8681 m³/s. A verificação usa o arquivo vigente no
painel e requer um valor válido por dia. O SAR do pacote cobre 18 dias de outubro. Como o treino e o
backtest usam o SAR, a comparação com o ONS é apresentada separadamente, fora do MAE de 21 meses.
