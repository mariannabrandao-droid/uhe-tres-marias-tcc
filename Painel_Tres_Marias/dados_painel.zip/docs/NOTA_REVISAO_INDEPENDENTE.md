# Revisão independente · UHE Três Marias

**Pergunta da defesa.** O que os registros horários de defluência revelam sobre baixas liberações diurnas que a média diária pode ocultar?

| Achado da auditoria | Tratamento nesta revisão |
|---|---|
| Convenção horária do ONS | Confirmada no catálogo oficial da base hidráulica horária. Hora final 01h representa 00h–00h59. O código conserva a conversão para hora de início e usa a janela de 06h a 18h, com 12 intervalos. |
| 8 dias em outubro de 2026 e 29 em outubro de 2025 | A tabela do painel explicita datas, denominador e proporções. Com 300 m³/s, foram 8/31 dias elegíveis em 2026 (22–26 e 29–31/10) e 29/30 em 2025. Recorrência mensal não equivale a frequência anual. |
| Telemetria de jusante | O CSV convencional de 41020002, baixado em 12/11/2026, termina em 31/10/2006. O posto também aparece na aba telemétrica, mas a exportação de 21–23/10/2026 não foi concluída. Para cobrir todos os dias sinalizados, solicitar os registros de 21/10 a 01/11, com unidade, fuso, convenção de horário e qualificação. Se houver apenas nível, verificar a curva-chave aplicável antes de derivar vazão. |
| Inventário por nome | Explicitada a presença de homônimos. Porto Indaiá oferece referência de tributário a montante e a série auxiliar 40990080 continua com identidade física em aberto. Adicionada a vazão diária de Pirapora Barreiro (41135000), em outro ponto a jusante, com série bruta até 31/07/2026 e consistida até 31/12/2023. |
| Artigos ausentes no ambiente da auditoria | O ZIP local de referências passou no teste de integridade. A matriz de rastreabilidade registra, entre outros, Cataldi et al. (2025), seções 2.2 e 4.3 e tabela 2, Vilar (2020), cap. 4, e Paiva, Barros e Valença, resumo e seção da área de estudo. O mapa climático representa os recortes da Tabela 2. A geometria usada para gerar os índices do CSV requer documentação de origem. |
| Word e painel em escopos diferentes | A previsão Ridge continua fora da apresentação. A comparação da previsão do ONS de maio–junho/2025 é complementar. A nota abaixo orienta a revisão do texto. |

## Ajustes para o Word

- **Resumo, abstract e objetivos:** substituir a promessa de previsão Ridge, seus valores de MAE e a contagem de meses-alvo pela pergunta da defesa e pelos resultados de escala temporal reproduzidos. Descrever a capa e as cinco páginas do painel.
- **Delimitação e metodologia:** definir o estudo como uma análise de escala temporal, cobertura e recorrência dos registros de defluência. A avaliação de uma obrigação operativa demanda a identificação da regra aplicável e observações validadas no ponto de controle.
- **Sazonalidade:** nomear maio–outubro como recorte analítico do painel. A Resolução ANA 2.081/2017, art. 2º, define maio–novembro como período operativo seco. Para períodos diferentes usados em estudos climatológicos citados, identifique fonte, variável e recorte antes de comparar.
- **Resultados:** apresentar primeiro a comparação dos dois outubros e depois o episódio de 22/10/2026. Manter o caso de maio–junho/2025 em seção complementar. Identificar o posto de Pirapora como contexto de outro ponto e outra frequência.

## Conclusão proposta

A leitura horária da descarga de Três Marias identificou períodos de baixa defluência diurna em dias cuja média oficial atingiu o patamar analítico de 300 m³/s. Foram 29 de 30 dias elegíveis em outubro de 2025 e 8 de 31 em outubro de 2026. Em 22/10/2026, a média foi 450 m³/s e houve cinco intervalos diurnos consecutivos abaixo do patamar, com mínimo de 164 m³/s entre 13h e 14h. Os resultados delimitam datas e horários para solicitar e comparar registros no posto 41020002. A análise utiliza a descarga do reservatório e a verificação no posto de controle requer telemetria qualificada, alinhamento temporal e exame dos atos aplicáveis. Para avaliar impactos sobre os usos da água, também são necessários dados do trecho e dos usos expostos.

## Fontes primárias

- [ONS · base hidráulica horária e convenção de hora final](https://dados.ons.org.br/dataset/dados_hidrologicos_ho)
- [ANA · Resolução 2.081/2017, arts. 2º e 3º](https://www.gov.br/ana/pt-br/legislacao/resolucoes/resolucoes-regulatorias/2017/2081)
- [MPF · divulgação da ação e do pedido de 300 m³/s das 6h às 18h](https://www.mpf.mp.br/o-mpf/unidades/pr-mg/noticias/mpf-ajuiza-acao-para-garantir-vazao-minima-do-rio-sao-francisco-em-tres-marias-mg)
- [ANA · HidroWeb, consulta por código de estação](https://www.snirh.gov.br/hidroweb/serieshistoricas)

## Verificação desta revisão

Testes executados em Linux com Python 3.12. A suíte verificou os cálculos de defluência, as seis telas pelo Streamlit AppTest, a seleção de dois meses, os downloads e as datas de cobertura de Pirapora. A validação visual em navegador e a execução no Windows não foram realizadas nesta rodada.
