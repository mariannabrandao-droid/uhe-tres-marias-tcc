**Chuva.** No Barramento, na defasagem zero, C e AB apresentam as associações positivas mais altas com a chuva mensal. Após descontar a sazonalidade, C tem r = 0,671 e AB tem r = 0,633 (220 pares). As faixas de sensibilidade se sobrepõem. Sul apresenta a associação inversa mais alta entre os recortes de bloqueio nessa comparação (r = −0,395), com magnitudes próximas às dos subrecortes ao retirar anos.

**Vazão.** No Indaiá, C tem r = 0,486 após o ajuste sazonal, com 295 pares. Para vazão natural SAR, os índices de ZCAS passam de r entre 0,413 e 0,675 nos dados brutos para r entre 0,032 e 0,169 nas anomalias (49 pares). Nesse recorte recente, a ordem varia com o ajuste sazonal e a retirada de anos. O bloqueio Sul H2 tem r = −0,321 na vazão natural ajustada, com faixa de −0,370 a −0,297. A janela recente e as regiões sobrepostas limitam a comparação entre recortes.

**Defasagem chuva–vazão.** Para Andrequicé e vazão natural SAR, nas anomalias mensais, r é 0,363 no mês corrente (74 pares), 0,498 a um mês (75), 0,566 a dois (76) e 0,271 a três (76). A chuva pontual e a agregação mensal limitam a interpretação física do pico. O resultado sugere associação antecedente e não estima tempo de viagem.

**Comparação com a literatura.** Cataldi et al. (2025, seção 2.2 e tabela 2) fundamentam os recortes regionais de ZCAS e bloqueio. O painel aplica esses recortes às séries selecionadas e informa o período comum e a sensibilidade à retirada de anos.

Para Três Marias, Cataldi et al. (2025, seção 4.3) reportaram associação positiva de 0,53 entre ZCAS e vazão em seu estudo regional de 1981–2023. A associação bruta do painel também é positiva. O ajuste por mês e a janela local mais curta reduzem os coeficientes. As magnitudes não constituem replicação direta.
