# Validação da edição de operação

| Verificação | Evidência |
|---|---|
| Cálculos históricos do SAR e clima | `calculos_reexecucao.log` e `testar_calculos_defesa.py` |
| Dois outubros, duração e controles de atualização | `calculos_operacao.log` e `testar_operacao.py` |
| Cinco páginas, filtros, CSVs, estados sem dados e botão | `interface_operacao.log` e `testar_interface_defesa.py`, com Streamlit AppTest |
| Consulta real dos arquivos oficiais do ONS | `atualizacao_ons_real.log`, teste de `operacao_ons.refresh` em diretório temporário |
| Inicialização da cópia de distribuição | `distribuicao.log` |

Testes executados em Linux, Python 3.12.14. A validação de interface usou Streamlit AppTest. A navegação visual em Chromium e a execução no Windows não foram verificadas nesta edição. A geração horária usa o identificador MGTMAR, com agregação de 24 horas válidas. A atualização da previsão e a consulta automática ao posto 41020002 dependem, respectivamente, de série pública recorrente e acesso à fonte com cobertura validada.

Para repetir a consulta real, execute `python -c "from operacao_ons import refresh; print(refresh(['2026-10','2026-11']))"` na pasta da aplicação. O comando consulta os arquivos e atualiza o cache local. Os valores públicos podem mudar com revisões.

## Revisão UFF

- `interface_revisao_uff.log` registra a execução das cinco páginas, a mudança de ambos os seletores, os downloads, a conferência previsão–consolidação e o botão de boletins com resposta simulada.
- `validacao_revisao_uff.log` registra as reexecuções de cálculo, a consulta real de boletins, a verificação dos nove meses e o início do servidor em Linux. Os links exibidos foram extraídos do índice da ANA, sem solicitar credenciais.

## Rodada final de 15/11/2026

- Sete páginas, navegação, gráficos, filtros e downloads: `teste_interface_rodada_final.log`.
- SAR, clima, duração, alinhamento horário e cache: `teste_calculos_rodada_final.log`.
- Cliques reais em Atualizar dados e Buscar boletins recentes da ANA: `teste_fontes_rodada_final.log`.
  O teste do ONS isolou o cache da distribuição em uma pasta temporária. A data mais recente da lista
  encontrada no índice da ANA foi 13/11/2026. Os resultados de uma nova consulta podem mudar.
- Conferência das sete figuras e dos dois quadros com o Word comentado: `FIGURAS_E_PREVISAO.md`.
- Foram verificadas a execução do servidor em Linux e a interface com Streamlit AppTest. A conferência
  visual em navegador a 100% e a execução no Windows ficaram pendentes.
