# Validação da revisão para defesa

Verificações realizadas em Linux, com Python 3.12, em 12/11/2026.

- As seis telas passaram em testes Streamlit AppTest. Foram exercitados o início do roteiro, os grupos de chuva, vazão e vertimento, a terceira série de vazão, o inventário com 45 postos, os filtros climáticos, os dois meses da análise diária e horária e os downloads.
- O maior vertimento médio foi de 1.717,8 m³/s em fevereiro de 2022. A média foi positiva em 20 de 81 meses completos do SAR. Os gráficos diários do mês vêm da mesma base.
- Andrequicé e vazão natural do SAR, no exemplo de anomalias com defasagem de dois meses, resultaram em r = 0,566 com 76 pares. A dispersão usa esses mesmos pares.
- A janela de 05/05 a 30/06/2025 contém 57 registros de vazão natural verificada pelo ONS. A média é 186,76 m³/s. A diferença assinada em relação aos 192 m³/s da apresentação é −5,24 m³/s.
- A atualização real, em pasta temporária, recebeu cinco arquivos do ONS para outubro e novembro de 2026. A hidráulica diária de 2026 retornou 315 registros da usina. O índice real da ANA devolveu cinco boletins com datas de 05 a 11/11/2026.
- A importação manual aceitou 744 registros de um CSV oficial de geração de outubro de 2026. Um CSV inválido foi rejeitado e a cópia anterior foi preservada.
- A tentativa de executar Chromium foi bloqueada pelo ambiente de teste. A renderização em navegador e a rede corporativa no Windows permanecem sem teste.
