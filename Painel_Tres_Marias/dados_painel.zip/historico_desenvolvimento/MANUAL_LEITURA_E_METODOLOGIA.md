# Manual científico

## Bases e completude

| Série | Fonte local | Resolução e regra |
|---|---|---|
| Vazão natural, afluência, defluência, cota, volume útil, turbinada e vertida | SAR/ANA, `entradas/sar_diario.csv` e `resultados/04_sar_mensal_cobertura_por_variavel.csv` | Média dos registros diários por mês e variável, com cobertura integral. Janeiro/2020 a setembro/2026 completos. Outubro tem 18 de 31 dias (58,06%), até 18/10/2026. |
| Chuva pontual | Hidroweb/ANA, `resultados/mensal/*_Chuvas.csv` | Soma dos dias admitidos com mês completo. Barramento (01845009), Mesquita (01944060) e Andrequicé (01845032) são séries independentes. Andrequicé termina em julho/2026. |
| Vazões de postos | Hidroweb/ANA, `resultados/mensal/*_Vazoes.csv` | Média mensal dos dias admitidos. Jusante (41020002) e Indaiá (40963000) são séries de postos, com regimes e períodos próprios. |
| ZCAS AB, C e DE | Índices fornecidos, `entradas/zcas_diario_fornecido.csv` e `resultados/11_indices_climaticos_mensais.csv` | Média diária agregada ao mês com cobertura integral. Os índices regionais vão até dezembro/2025. |
| Bloqueios | Campos fornecidos, `entradas/bloqueio_total_campos.csv` e `resultados/11_indices_climaticos_mensais.csv` | Contagem mensal de dias em sequências de pelo menos 3 dias com an_geop500, vort850 e vort500 simultaneamente positivos, segundo a rotina do acervo. Só meses com dias completos. |

Todos os caminhos da tabela pertencem a `ANA_Etapa02`. A página histórica mostra o primeiro e último mês válido, a contagem observada e a quantidade de meses no intervalo. As lacunas permanecem ausentes e os zeros válidos são preservados. A limpeza anterior dos postos prioriza nível de consistência 2 sobre 1, resolve duplicidades idênticas e exclui dias com conflito dentro de qualquer nível de consistência. As tabelas `02_qualidade_e_cobertura.csv` e `09_historico_limpeza.csv` registram as decisões. `hidroclima.read_series` mantém todas as séries em calendário mensal comum e separa suas origens. Os valores de volume útil acima de 100% permanecem na fonte e são sinalizados no histórico.

## Página 01 · Três Marias em contexto

`app.context` mostra a média do último mês completo de cada grandeza SAR. O mapa é a imagem da Figura 2 do PDF do TCC, creditada no rascunho a Silva et al. (2015), com escala gráfica original e Três Marias já indicada. O fluxo didático descreve afluência, estoque, geração e liberação a jusante. O boxplot `app.seasonality` agrupa valores mensais por mês calendário para mostrar quartis, mediana e extremos na janela disponível.

## Página 02 · Histórico e clima

- **Séries, comparação e sazonalidade** · `app.time_series` conserva lacunas. `hidroclima.coverage` conta os meses válidos e de calendário entre as pontas observadas. `app.history` compara médias e medianas entre 2020–2022 e 2023–2026 para SAR e divide as outras séries no ano central da janela. Períodos podem ter composição sazonal diferente.
- **Associação com defasagem** · `hidroclima.paired_months` forma pares X(t), Y(t+k) no calendário mensal antes de retirar ausências. A página restringe a série à janela entre o primeiro e o último mês contemporâneo em comum. Em cada k, a tabela informa n, datas em X e Y e Pearson. No modo anomalias, cada série é centrada por sua média de mês calendário na janela comum, antes do deslocamento. Pearson é Σ[(x−x̄)(y−ȳ)] / √[Σ(x−x̄)² Σ(y−ȳ)²]. Com n<3 ou variância zero, r fica indefinido. A amostra pode variar entre defasagens. Os índices foram explorados descritivamente. Sazonalidade e autocorrelação afetam a interpretação de r.
- **Previsão direta M+1 a M+3** · `modelagem_temporal.prepare` e `make_examples` fornecem Q(t), Q(t−1), Q(t−2), Q(t−3), Q(t−6), Q(t−12), seno e cosseno de 2π·mês-alvo/12. O alvo é vazão natural média mensal Q(t+h). `calibracao_final.fit_predict` ajusta o padronizador dentro do treino e minimiza Σ(y−ŷ)² + αΣβ² por Ridge. A saída negativa é truncada em zero. `select_alpha` usa MAE em até seis origens internas recentes e α em {1, 10, 100}. Exige 24 pares internos e pelo menos três avaliações ou usa α=10. Todo alvo de treino do Ridge tem mês anterior à origem da rodada.
- **Referências simples** · Persistência usa Q(t). Climatologia calcula a média de Q dos meses do calendário iguais ao mês-alvo dentre os observados até t. Todas as comparações usam os mesmos alvos por horizonte. A escolha usa somente o M0. A chuva de Andrequicé termina antes da origem de emissão e o par climático recente é curto. Julho/2026 e janeiro/2024 são as últimas origens completas de M1 e M2 na preparação anterior.
- **Treino expansivo e seleção** · `previsao.run` exige 24 pares para o Ridge e usa candidatos de 2023–2024, encerrando a seleção antes da primeira origem da auditoria em cada horizonte. Os alvos de janeiro/2025 a setembro/2026 formam a auditoria posterior. A cada origem, o treino usa somente os alvos já elegíveis naquele ponto. `choose` minimiza a média dos postos do MAE global e seco (maio a outubro), incluindo o posto abaixo de 150 m³/s se houver pelo menos cinco meses baixos na seleção. O desempate usa MAE global, depois a ordem persistência, climatologia, Ridge. As tabelas permitem verificar desempenho com poucos eventos baixos.
- **Métricas e gráficos** · `previsao.metrics` calcula MAE = média de |ŷ−y|, RMSE = √média de (ŷ−y)², viés = média de (ŷ−y) e NSE = 1−Σ(ŷ−y)²/Σ(y−ȳ)², com ȳ da amostra avaliada. NSE fica ausente para variância zero. O gráfico retrospectivo (`app.forecast_page`) usa os alvos da auditoria. O gráfico de projeções (`app.show_projection_threshold`) destaca novembro/2026 (M+2, mês em curso) e inclui dezembro/2026 (M+3, horizonte complementar), com emissão de referência em 11/11/2026 e origem em setembro/2026. Na aba Referência climatológica do Laboratório, o limiar de comparação é independente dos demais. Ele altera a comparação com a faixa empírica. Outubro é uma estimativa retrospectiva sem mês observado completo. Novembro está em curso na emissão.
- **Incerteza** · `previsao.run` soma à estimativa os percentis empíricos 10 e 90 de y−ŷ do mesmo modelo e horizonte na auditoria, com piso zero. São 21 resíduos por combinação. Trata-se de faixa descritiva agrupando meses do calendário. A cobertura condicional de novembro e dezembro permanece indeterminada e a faixa não fornece probabilidade de cruzamento de limiar.

## Página 03 · Laboratório interativo de vazões

- **Permanência** · `hidroclima.permanence` ordena Q do maior ao menor e associa Pᵢ=100·i/(n+1). `reference_quantile` interpola linearmente Q90 e Q95 dentro da curva, sem extrapolar. As vazões permanecem em m³/s, calculadas sobre médias mensais.
- **Frequência e sequência** · `threshold_stats` calcula 100·#{Q<L}/n, excluindo ausências e mantendo empates na faixa igual ou acima. Os denominadores são próprios de cada mês, estação, temporada, período ou ano. `longest_below` conta meses consecutivos abaixo, interrompendo a sequência em lacunas ou valores ≥ L. Maio a outubro é a temporada seca adotada.
- **Clima e limiar** · `climate_comparison` usa meses presentes em cada par vazão–clima e compara medianas abaixo e a partir do limiar por temporada. Células com n baixo têm interpretação descritiva.
- **Comparação com as projeções** · `app.show_projection_threshold` compara o limiar de vazão natural com o ponto e a faixa de erro de novembro e dezembro. Mudar o limiar não recalibra o modelo. A avaliação de defluência mínima exige armazenamento, entradas, saídas, restrições e regras de operação. Médias mensais não descrevem atendimento diário nem critérios ecológicos.

## Página 04 · Síntese científica

`app.synthesis` mostra medianas sazonais, frequências de três cenários de limiar, associações contemporâneas e menor MAE observado por horizonte. O resumo separa a seleção do modelo, o desempenho na auditoria e a interpretação dos indicadores. Diferenças entre recortes não sustentam afirmações de tendência significativa.

## Página 05 · Métodos, fontes e referências

`app.methods` reproduz este manual e disponibiliza `01_decisao_45_estacoes.csv`, com coordenadas e decisões de uso. O inventário inclui séries sem CSV e estações fora do recorte principal. As coordenadas são cadastrais e o datum não está confirmado.

## Referências aplicadas

- **ANA SAR e Hidroweb** · Fontes das exportações locais, com trilha de seleção e limpeza preservada. Calegario et al., *Download e pré-processamento de dados hidroclimáticos do Hidroweb/ANA com o pacote HydroBR*, oferece contexto de processamento, e Zhao et al. (2018), *Research on the Data-Driven Quality Control Method of Hydrological Time Series Data*, contextualiza qualidade. O painel usa a regra de completude da base local.
- **Material do Prof. Márcio Cataldi** · `referencias_codigo/Professor_02_Data_Mining.ipynb` fundamenta a exploração por correlação. O alinhamento por calendário, os lags, a indicação de n e a validação preditiva são adaptações do projeto. Cataldi (2008), tese sobre anomalias de TSM e regime hidrometeorológico, e Cataldi et al. (2025), *Teleconnection Patterns and Synoptic Drivers of Climate Extremes in Brazil (1981–2023)*, contextualizam circulação e extremos. Os índices do painel são os fornecidos.
- **Machiwal e Jha (2006)** · *Time Series Analysis of Hydrologic Data for Water Resources Planning and Management*. Fundamentação geral para análise de séries. **Paiva, Barros e Valença**, *Aplicação do modelo Neuro3M para previsão de vazões naturais afluentes ao reservatório de Três Marias*, é um antecedente local de previsão com outra arquitetura e outros preditores.
- **Silva, Marques e Lemos** · *Avaliação de metodologias de regionalização de vazões mínimas de referência para bacia hidrográfica do rio São Francisco*. Contexto para Q90 e Q95. **Dyson, Bergkamp e Scanlon (orgs.)**, *Flow: The essentials of environmental flows*, e **Melo (2011)**, *Análise de critérios para definição de vazão remanescente em projetos de usinas hidrelétricas*, embasam a discussão sobre usos e critérios ambientais.

## Comparação diária e horária da defluência

O laboratório compara médias diárias do ONS com registros de defluência em intervalos horários diurnos para outubro de 2026. Consulte `dados_ons/README.md` para as fontes, recorte, convenção de horas e denominadores. O limiar diurno é independente do limiar mensal. Os 300 m³/s representam um cenário associado ao pedido divulgado pelo MPF. As séries operacionais têm resolução horária e não substituem a estação de controle 41020002 indicada no texto da Resolução ANA nº 2.081/2017.

<!-- anexos -->

O acervo de origem contém as rotinas de preparação e as análises exploratórias anteriores. O manual V5 foi preservado em `docs/MANUAL_V5_ARQUIVADO.md`. Os resultados que sustentam esta edição estão em `resultados_entrega`. Consulte `docs/AUDITORIA.md` para os valores reproduzidos e `docs/MUDANCAS_E_TCC.md` para reconciliar o rascunho acadêmico.

