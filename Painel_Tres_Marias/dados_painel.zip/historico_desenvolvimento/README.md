# Arquivo dos experimentos recebidos

Os módulos, tabelas e a interface antiga documentam as tentativas anteriores de previsão e seus resultados. Este diretório é histórico, com caminhos e dependências da edição recebida. A nova aplicação não utiliza estes experimentos para emissão de previsão ou simulação. Para reproduzir integralmente a edição antiga, use o ZIP original recebido com suas próprias instruções e dependências.
