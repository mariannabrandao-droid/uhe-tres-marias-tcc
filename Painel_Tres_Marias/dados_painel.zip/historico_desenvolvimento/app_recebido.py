"""Interface Streamlit da edição de cinco páginas."""
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

import hidroclima as hydro
from defluencia_diurna import THRESHOLD, analyze, read_october
from hidroclima import DATA, DAILY, DRY, FLOW, ISSUE, LABELS, ROOT, SAR, unit
from previsao import run
from mapas import local_map, network_map, regional_map
from evidencia_jusante import STATION, compare, load_station_csv, operational_context

st.set_page_config(page_title='Três Marias | Observatório Hidroclimático',page_icon='🌊',layout='wide',initial_sidebar_state='expanded')
st.markdown("""<style>

:root{--navy:#09233e;--navy2:#113957;--teal:#0b9a9c;--bg:#f3f7fb;--muted:#71839a;--line:#e1eaf2}
html,body,[class*=css],.stApp{font-family:'DM Sans',sans-serif!important}
.stApp,[data-testid=stAppViewContainer]{background:var(--bg)}
[data-testid=stHeader]{background:transparent;height:2.4rem}
[data-testid=stSidebar]{background:linear-gradient(180deg,#0a2744 0%,#102f4d 65%,#0b253f 100%)!important;border-right:1px solid #24415c}
[data-testid=stSidebar] *{color:#e8f3fa!important}
[data-testid=stSidebar] .stRadio label{padding:7px 10px;border-radius:10px;margin:1px 0;font-size:0.88rem}
[data-testid=stSidebar] .stRadio label:has(input:checked){background:#1b506c!important;border-left:3px solid #4bd0c7}
[data-testid=stSidebar] [data-testid=stAlert]{background:#183e58!important;border:1px solid #2c6077!important}
[data-testid=stSidebar] hr{border-color:#35516a}
.block-container{max-width:1500px!important;padding:1.4rem 2.6rem 5rem!important}
h1,h2,h3,h4{font-family:'Manrope',sans-serif!important;color:#132d48!important;letter-spacing:-.03em}
h1{font-size:1.8rem!important;font-weight:800!important;margin-bottom:1rem!important}
h2{font-size:1.24rem!important}h3{font-size:1.03rem!important}
.hero{background:linear-gradient(105deg,#0b2946 0%,#114767 68%,#087c89 100%);border-radius:18px;padding:29px 34px;color:#fff;margin-bottom:19px;box-shadow:0 12px 35px #102f4b12;position:relative;overflow:hidden}
.hero:after{content:'';position:absolute;right:-35px;top:-90px;width:330px;height:260px;border-radius:50%;border:45px solid #ffffff0c}
.hero h1{color:white!important;font-size:1.9rem!important;margin:0 0 5px!important}
.hero p{color:#bce1e7;margin:0;font-size:.92rem}.hero .eyebrow{font-size:.73rem;font-weight:800;letter-spacing:.14em;color:#61d3cc;margin-bottom:10px}
div[data-testid=stMetric]{background:#fff;border:1px solid var(--line);border-radius:14px;padding:17px 20px;box-shadow:0 5px 15px #15334d08;min-height:114px;border-top:3px solid #18a3a8}
[data-testid=stMetricLabel]{font-size:.84rem!important;color:#60758b!important}
[data-testid=stMetricValue]{font-size:1.75rem!important;font-weight:800!important;color:#102e49!important}
[data-testid=stVerticalBlockBorderWrapper]{border-radius:16px!important;border-color:var(--line)!important}
.stPlotlyChart{background:white;border-radius:16px;border:1px solid var(--line);padding:9px 12px;box-shadow:0 5px 20px #16374b09;overflow:hidden}
[data-testid=stDataFrame]{background:#fff;border:1px solid var(--line);border-radius:12px;overflow:hidden}
[data-testid=stAlert]{border-radius:12px!important}
.stButton>button,.stDownloadButton>button{background:#0d6e81;color:white;border:none;border-radius:10px;font-weight:700;padding:9px 18px}
.stButton>button:hover,.stDownloadButton>button:hover{background:#0a4c66;color:white}
[data-testid=stSelectbox], [data-testid=stMultiSelect], [data-testid=stSlider]{border-radius:10px}
.smallhead{font-size:.72rem;font-weight:800;letter-spacing:.13em;color:#0b9298;margin-bottom:4px}
.sectionintro{color:#6b7d90;font-size:.92rem;margin-top:-.65rem;margin-bottom:1.2rem}
.pill{display:inline-block;background:#e1f4f4;border:1px solid #b8e4e4;color:#176d76;border-radius:20px;font-size:.74rem;padding:4px 11px;margin:0 5px 7px 0;font-weight:700}
.footerline{margin-top:25px;padding-top:16px;border-top:1px solid #d9e5ed;color:#788a9a;font-size:.78rem}
.stApp [data-testid='stSidebar'] [role='radiogroup'] label{transition:background .2s ease}.stApp [data-testid='stSidebar'] [role='radiogroup'] label:hover{background:#19445d!important}.stApp [data-testid='stHorizontalBlock']{align-items:stretch}.stApp [data-testid='stMetric']{height:100%}.stApp [data-testid='stDataFrame']{font-size:.86rem}.stApp .stTabs [data-baseweb='tab']{font-weight:700}.insight{background:#eff8fb;border-left:4px solid #0d9eaa;padding:13px 17px;border-radius:10px;color:#21465b;margin:12px 0}.warningbox{background:#fff6e8;border-left:4px solid #e59a31;padding:13px 17px;border-radius:10px;color:#70542b;margin:12px 0}@media(max-width:850px){.block-container{padding:1rem .8rem 3rem!important}.hero{padding:21px}.hero h1{font-size:1.45rem!important}}
</style>""",unsafe_allow_html=True)
st.markdown('<div class="hero"><h1>UHE Três Marias</h1><p>Painel hidroclimático do Rio São Francisco · TCC UFF</p></div>',unsafe_allow_html=True)
st.caption('Plataforma acadêmica independente  •  Bases históricas locais  •  Atualização não automática  •  Resultados com proveniência identificada')

def graph(fig,key,height=355):
 fig.update_layout(template='plotly_white',height=fig.layout.height or height,margin=dict(l=18,r=18,t=55,b=65),
  paper_bgcolor='#ffffff',plot_bgcolor='#ffffff',font=dict(family='DM Sans, Arial',color='#425d73',size=12),
  title_font=dict(family='Manrope, Arial',size=15,color='#15334d'),
  legend=dict(orientation='h',y=-.28,x=0,font=dict(size=11)),
  hovermode=fig.layout.hovermode or 'x unified',colorway=['#087eae','#12a9a0','#f3a54b','#8c70c9','#df7185'],
  xaxis=dict(showgrid=False,zeroline=False),yaxis=dict(gridcolor='#edf2f6',zeroline=False))
 st.plotly_chart(fig,width="stretch",key=key,config={'displaylogo':False,'responsive':True})

MONTHS = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez']
PAGES = (
    '01 · Três Marias em contexto',
    '02 · Histórico e clima',
    '03 · Laboratório de vazões e cenários',
    '04 · Síntese científica',
    '05 · Métodos, fontes e referências',
)
COLORS = {'Observada': '#112e4b', 'Persistência': '#ae6832', 'Climatologia': '#0a9291', 'Ridge': '#7461a6'}


@st.cache_data
def load_history():
    return hydro.read_series(), hydro.complete_sar(), pd.read_csv(DAILY, parse_dates=['data'])


@st.cache_data(show_spinner='Recalculando o backtest temporal…')
def load_forecast():
    return run()


def number(value, places=1):
    if pd.isna(value):
        return '—'
    return f'{value:,.{places}f}'.translate(str.maketrans(',.', '.,'))


def month(date):
    return date.strftime('%m/%Y') if pd.notna(date) else '—'


def table(frame):
    st.dataframe(frame, width='stretch', hide_index=True)


def figure(fig, key, caption):
    graph(fig, key)
    st.caption(caption)


def time_series(frame, keys, title, key):
    chart = go.Figure()
    for name in keys:
        chart.add_scatter(x=frame.index, y=frame[name], name=LABELS[name], mode='lines',
                          connectgaps=False)
    chart.update_layout(title=title, yaxis_title=unit(keys[0]), xaxis_title='Mês')
    figure(chart, key, 'Valores mensais completos na escala indicada. Interrupções representam ausências. '
           'Código · hidroclima.read_series → app.time_series.')


def seasonality(frame, key, chart_key):
    data = frame[key].dropna().rename('Valor').to_frame()
    data['Mês'] = [MONTHS[i - 1] for i in data.index.month]
    data['Amostra'] = data.groupby('Mês')['Valor'].transform('size')
    chart = px.box(data, hover_data=['Amostra'], x='Mês', y='Valor', category_orders={'Mês': MONTHS}, points='outliers',
                   labels={'Valor': unit(key)}, title=f'Sazonalidade · {LABELS[key]}')
    counts = data.groupby(data.index.month).size()
    chart.update_xaxes(tickvals=[MONTHS[i-1] for i in counts.index],
                       ticktext=[f'{MONTHS[i-1]}<br>n={n}' for i, n in counts.items()])
    source = ' · SAR' if key in SAR else ''
    figure(chart, chart_key, f'Período: {month(data.index.min())} a {month(data.index.max())}{source}. '
           'Cada caixa reúne o mesmo mês em anos diferentes. A linha interna é a mediana.')


def setup():
    st.sidebar.markdown('### UHE Três Marias')
    selected = st.sidebar.radio('Páginas', PAGES)
    st.sidebar.caption(f'Data de referência do estudo · {ISSUE:%d/%m/%Y}')
    st.sidebar.caption('Dados locais do TCC. As séries têm janelas de disponibilidade próprias.')
    return selected


def context(sar, daily):
    st.header('Três Marias em contexto')
    st.write('A UHE está no alto curso do Rio São Francisco, em Minas Gerais. O reservatório armazena água '
             'e permite deslocar parte da liberação no tempo. A disponibilidade e a vazão a jusante '
             'interessam à geração, ao abastecimento, à irrigação e aos ecossistemas aquáticos.')
    for cell, key in zip(st.columns(4), (*FLOW, 'volume_util_pct')):
        valid = sar[key].dropna()
        with cell:
            st.metric(LABELS[key], f'{number(valid.iloc[-1])} {unit(key)}')
            st.caption(f'Média de {month(valid.index[-1])} · SAR')
    st.caption(f'Último dia registrado no SAR · {daily.data.max():%d/%m/%Y}. '
               'Os cartões usam o último mês completo de cada série.')
    st.subheader('Onde a usina e a estação de controle ficam')
    regional, local = st.tabs(['Região Hidrográfica São Francisco', 'Barramento e jusante'])
    with regional:
        figure(regional_map(), 'map_region',
               'Limite da região hidrográfica da ANA/SNIRH. O ponto marca o posto do Barramento. '
               'O contorno representa a região do São Francisco como um todo.')
    with local:
        figure(local_map(), 'map_local',
               'Trechos da Base Hidrográfica Ottocodificada (ANA/SNIRH). Marcadores do cadastro ANA. '
               'O posto do Barramento é a referência cartográfica da usina e 41020002 é a estação a jusante. '
               'Coordenadas cadastrais sujeitas a conferência de campo.')
    left, right = st.columns([1, 1.2])
    with left:
        st.subheader('Da operação à observação')
        st.write('A série SFTMAR do ONS registra a defluência do reservatório. A estação 41020002 '
                 'é o ponto de controle a jusante indicado no texto da Resolução ANA 2.081/2017. '
                 'A comparação do Laboratório usa a série do ONS.')
        st.link_button('Consultar o texto da resolução', 
                       'https://www.gov.br/ana/pt-br/legislacao/resolucoes/resolucoes-regulatorias/2017/2081')
    with right:
        st.subheader('Como a água passa pela usina')
        st.markdown('**Rio a montante → Reservatório → Turbinas ou vertedouro → Rio a jusante**')
        st.caption('Nas turbinas, o movimento da água aciona os geradores. O vertedouro libera água por outra rota.')
        for title, body in (
            ('1. Afluência', 'Água que chega ao reservatório pelos rios e contribuições da área drenante.'),
            ('2. Reservatório e armazenamento', 'O nível varia à medida que o volume armazenado muda. '
             'O volume útil em % expressa o armazenamento em relação à faixa útil de referência.'),
            ('3. Turbinas e vertedouro', 'A diferença de nível permite que o escoamento movimente turbinas ligadas a geradores. '
             'O vertedouro fornece uma rota adicional de liberação.'),
            ('4. Defluência', 'Água liberada a jusante, incluindo parcelas turbinadas e vertidas.'),
        ):
            with st.container(border=True):
                st.markdown(f'**{title}**')
                st.write(body)
        st.caption('Sequência didática do fluxo. Código · app.context.')
        st.info('Vazão natural é uma série de referência reconstituída para representar o escoamento sob '
                'condições naturais segundo a metodologia de origem. Afluência e defluência descrevem '
                'a entrada e a saída do reservatório. Volume útil é armazenamento relativo.')
    seasonality(sar, FLOW[0], 'context_season')


def history(frame, sar, daily):
    groups = {
        'Vazões SAR': list(FLOW),
        'Vazões de postos': ['vazao_jusante_m3s', 'vazao_indaia_m3s'],
        'Precipitação pontual': [k for k in LABELS if k.startswith('chuva')],
        'ZCAS': ['SACZ_AB', 'SACZ_C', 'SACZ_DE'],
        'Bloqueios': ['dias_bloqueio_total'],
        'Volume útil': ['volume_util_pct'],
        'Cota': ['cota_m'],
        'Vazões turbinada e vertida': ['turbinada_m3s', 'vertida_m3s'],
    }
    group = st.selectbox('Grupo de séries', groups)
    descriptions = {
        'Vazões SAR': 'Vazão natural reconstituída, entrada (afluência) e saída (defluência) do reservatório.',
        'Vazões de postos': 'Registros de vazão em estações fluviométricas distintas.',
        'Precipitação pontual': 'Chuva medida em cada posto. Cada série representa o local de medição.',
        'ZCAS': 'Índices mensais regionais da Zona de Convergência do Atlântico Sul.',
        'Bloqueios': 'Número de dias com bloqueio atmosférico na série de referência.',
        'Volume útil': 'Percentual de ocupação da faixa útil de armazenamento.',
        'Cota': 'Nível da superfície do reservatório em metros.',
        'Vazões turbinada e vertida': 'Água liberada pelas turbinas e pelo vertedouro.',
    }
    st.write(descriptions[group])
    keys = groups[group]
    subset = frame[keys].dropna(how='all').asfreq('MS')
    time_series(subset, keys, group, 'history_series')
    rows = []
    for key in keys:
        row = hydro.coverage(subset[key])
        rows.append({'Série': LABELS[key], 'Início': month(row['inicio']), 'Fim': month(row['fim']),
                     'Meses válidos': row['n'], 'Meses no intervalo': row['meses_calendario']})
    table(pd.DataFrame(rows))
    st.caption('Cada linha usa a janela entre o primeiro e o último mês válido da própria série. '
               'Código · hidroclima.coverage.')
    if group == 'Volume útil':
        days = daily.loc[daily.volume_util_pct.gt(100), ['data', 'volume_util_pct']]
        months = sar.volume_util_pct.gt(100).sum()
        st.info(f'O SAR registra {len(days)} dias e {months} médias mensais completas acima de 100%. '
                'Os valores originais foram mantidos. Consulte a fonte antes de interpretar esses registros.')
        with st.expander('Registros diários acima de 100%'):
            table(days.assign(data=days.data.dt.strftime('%d/%m/%Y')))
    key = keys[0] if len(keys) == 1 else st.selectbox('Série para detalhar', keys, format_func=LABELS.get)
    seasonality(subset, key, 'history_season')
    values = subset[key].dropna().rename('Valor')
    if key in SAR:
        periods = hydro.period_groups(values.index)
    else:
        midpoint = (values.index.min().year + values.index.max().year) // 2
        periods = pd.Series(np.where(values.index.year <= midpoint, f'Até {midpoint}',
                                     f'A partir de {midpoint+1}'), index=values.index)
    comparison = values.groupby(periods).agg(['count', 'median', 'mean']).round(2)
    with st.expander(f'Comparação entre períodos · {LABELS[key]}'):
        table(comparison.rename_axis('Período').reset_index().rename(
            columns={'count': 'n', 'median': 'Mediana', 'mean': 'Média'}))
        st.caption('Resumo descritivo por janela. Diferenças podem refletir a cobertura sazonal de cada série. '
                   'Código · app.history.')


PAIRS = {
    'Chuva em Andrequicé → vazão natural': ('chuva_andrequice_mm', FLOW[0],
        'Chuva antecedente pode acompanhar a resposta do escoamento e o armazenamento na bacia. '
        'Andrequicé é um posto pontual.'),
    'ZCAS AB → chuva no Barramento': ('SACZ_AB', 'chuva_barramento_mm',
        'A associação descreve a coincidência temporal do índice regional com a chuva no posto.'),
    'Bloqueios → chuva no Barramento': ('dias_bloqueio_total', 'chuva_barramento_mm',
        'Os bloqueios podem alterar a circulação e a distribuição da chuva. O sinal é específico do recorte.'),
    'Chuva no Barramento → vazão no Indaiá': ('chuva_barramento_mm', 'vazao_indaia_m3s',
        'As duas séries representam locais distintos. A associação regional pode refletir sazonalidade comum.'),
}


def correlations(frame):
    choice = st.selectbox('Par de séries (X → Y)', PAIRS)
    x, y, interpretation = PAIRS[choice]
    st.write(f'**{LABELS[x]} ({unit(x)}) × {LABELS[y]} ({unit(y)})**')
    st.write(interpretation)
    st.caption('Defasagem 0 compara o mesmo mês. Na defasagem 1, a segunda série é lida um mês depois.')
    if x == 'SACZ_AB':
        st.caption('AB é a identificação do recorte regional na base de índices de ZCAS.')
    window = frame[[x, y]].dropna().index
    if window.empty:
        st.warning('Sem mês comum válido para este par.')
        return
    sample = frame.loc[window.min():window.max()]
    anomaly = st.toggle('Remover a média de cada mês do calendário',
                        help='Compara desvios em relação à média histórica de cada mês em cada série.')
    st.caption(f'Janela comum: {month(window.min())} a {month(window.max())}.')
    rows = pd.DataFrame([hydro.correlation(sample, x, y, k, anomaly) for k in range(4)])
    chart = px.bar(rows, x='k', y='r', hover_data=['n'], text='n', range_y=[-1.12, 1.12],
                   labels={'k': 'Defasagem (meses)', 'r': 'Pearson r'},
                   title='Associação mensal por defasagem')
    chart.update_xaxes(dtick=1)
    chart.update_traces(texttemplate='n=%{text}', textposition='outside')
    figure(chart, 'lag', 'X(t) comparado a Y(t+k). A amostra pode variar entre defasagens. '
           'Código · hidroclima.paired_months e correlation.')
    for col in ['inicio_x', 'fim_x', 'inicio_y', 'fim_y']:
        rows[col] = rows[col].map(month)
    table(rows.round({'r': 3}).rename(columns={'k': 'Defasagem', 'r': 'Pearson r', 'n': 'Pares válidos',
          'inicio_x': 'Início X', 'fim_x': 'Fim X', 'inicio_y': 'Início Y', 'fim_y': 'Fim Y'}))
    st.caption('Pearson mede associação linear. Sazonalidade e autocorrelação podem influenciar r. '
               'Correlação não demonstra causalidade.')


def projection_table(projections):
    selected = projections.copy()
    selected.alvo = selected.alvo.map(month)
    selected.horizonte = selected.horizonte.map(lambda value: f'M+{value}')
    fields = {'horizonte': 'Horizonte', 'alvo': 'Alvo', 'situacao': 'Situação em 11/11',
              'modelo': 'Modelo', 'previsto': 'Estimativa (m³/s)', 'faixa_inf': 'Faixa inferior',
              'faixa_sup': 'Faixa superior', 'selecionado': 'Selecionado'}
    table(selected[list(fields)].round(1).rename(columns=fields))
    st.caption('Faixa empírica por modelo e horizonte, em m³/s, baseada nos quantis 10% e 90% '
               'dos erros retrospectivos observado − previsto. Cobertura futura não aferida. '
               'Código · previsao.run.')


def scenario_input(container=st):
    if 'scenario_limit' not in st.session_state:
        st.session_state.scenario_limit = 150.0
    if '_scenario_limit' not in st.session_state:
        st.session_state._scenario_limit = st.session_state.scenario_limit

    def save_limit():
        st.session_state.scenario_limit = st.session_state._scenario_limit

    return container.number_input('Vazão de referência (m³/s)', min_value=0.0,
                                  step=5.0, format='%.2f', key='_scenario_limit',
                                  on_change=save_limit)


def forecast_page(sar):
    backtest, metrics, projections = load_forecast()
    reference = projections.iloc[0]
    st.subheader('Projeção experimental de vazão natural')
    primary, complementary = displayed_projections(projections).itertuples(index=False)
    metadata = st.columns(3)
    metadata[0].metric('Emissão de referência', f'{reference.emissao:%d/%m/%Y}')
    metadata[1].metric('Origem · último mês completo', month(reference.origem))
    metadata[2].metric('Mês-alvo em destaque', f'{MONTHS[primary.alvo.month-1]}/{primary.alvo.year}')
    st.write(f'**{MONTHS[primary.alvo.month-1]}/{primary.alvo.year} · M+{primary.horizonte} · '
             f'{number(primary.previsto)} m³/s** · {primary.modelo}. Mês em andamento na emissão.')
    st.caption(f'{MONTHS[complementary.alvo.month-1]}/{complementary.alvo.year} · M+{complementary.horizonte} '
               '· Horizonte complementar. Outubro teve 18 de 31 dias disponíveis no SAR.')
    st.caption('A climatologia usa a média histórica do mês-alvo até a origem. Novembro estava em '
               'andamento em 11/11. A estimativa usa os dados completos disponíveis até setembro.')
    limit = st.number_input('Limiar para comparar com a climatologia (m³/s)', min_value=0.0,
                            value=150.0, step=5.0, key='forecast_limit')
    show_projection_threshold(projections, limit, sar[FLOW[0]])
    st.caption('O limiar altera a comparação com a projeção. A estimativa e a faixa dependem do modelo.')
    with st.expander('Estimativas por modelo e mês-alvo'):
        projection_table(projections)
        st.caption('Outubro tem observação parcial. Novembro estava em curso na data de emissão.')
    st.subheader('Desempenho retrospectivo')
    h = st.selectbox('Horizonte do backtest', (1, 2, 3), index=1, format_func=lambda value: f'M+{value}')
    audit = backtest.query("etapa == 'Auditoria' and horizonte == @h")
    development = backtest.query("etapa == 'Seleção' and horizonte == @h")
    ridge = audit[audit.modelo.eq('Ridge')]
    trained = projections.query("horizonte == @h and modelo == 'Ridge'").iloc[0]
    st.write(f'**Seleção retrospectiva** · alvos de {month(development.alvo.min())} a {month(development.alvo.max())}. '
             f'**Auditoria posterior** · alvos de {month(audit.alvo.min())} a {month(audit.alvo.max())}.')
    selected = projections.query('horizonte == @h and selecionado').iloc[0]
    st.write(f'**Modelo selecionado para M+{h}** · {selected.modelo}. Primeira origem auditada em '
             f'{month(audit.origem.min())}.')
    st.caption('A seleção usa a média dos postos de MAE global e seco, incluindo o recorte de baixa '
               'vazão quando há pelo menos cinco meses baixos na seleção. O menor MAE global desempata.')
    st.caption(f'Ridge na primeira rodada auditada · treino de alvos {month(ridge.iloc[0].treino_inicio)} a '
               f'{month(ridge.iloc[0].treino_fim)}. Ajuste para emissão · {month(trained.treino_inicio)} a '
               f'{month(trained.treino_fim)} ({trained.n_treino} pares). A climatologia usa as observações '
               'da série até a origem, agrupadas pelo mês do alvo.')
    chart = go.Figure()
    chart.add_scatter(x=ridge.alvo, y=ridge.observado, name='Observada', line=dict(color=COLORS['Observada']))
    for model, rows in audit.groupby('modelo'):
        chart.add_scatter(x=rows.alvo, y=rows.previsto, name=model, line=dict(color=COLORS[model], dash='dot'))
    chart.update_layout(title=f'Auditoria retrospectiva · M+{h}', xaxis_title='Mês-alvo',
                        yaxis_title='Vazão natural (m³/s)')
    dates = pd.date_range(audit.alvo.min(), audit.alvo.max(), freq='2MS')
    chart.update_xaxes(tickvals=dates, ticktext=[month(d) for d in dates],
                       range=[audit.alvo.min()-pd.Timedelta(days=12),
                              audit.alvo.max()+pd.Timedelta(days=12)], fixedrange=True)
    figure(chart, 'backtest', 'Alvos observados e estimativas feitas nas respectivas origens históricas. '
           'Código · previsao.run.')
    columns = ['modelo', 'recorte', 'n', 'MAE', 'RMSE', 'vies', 'NSE']
    for stage, heading in [('Auditoria', 'Métricas de auditoria'), ('Seleção', 'Métricas usadas na seleção')]:
        with st.expander(heading, expanded=stage == 'Auditoria'):
            table(metrics.query('etapa == @stage and horizonte == @h')[columns].round(2).rename(
                columns={'vies': 'Viés', 'modelo': 'Modelo', 'recorte': 'Recorte'}))
            st.caption('MAE, RMSE e viés em m³/s. NSE adimensional. Seca definida de maio a outubro. '
                       'Código · previsao.metrics.')
    audit_cuts = metrics.query("etapa == 'Auditoria' and horizonte == @h")
    leaders = [rows.loc[rows.MAE.idxmin()] for _, rows in audit_cuts.groupby('recorte', sort=False)]
    st.caption('Menor MAE por recorte · ' + ' | '.join(
        f'{r.recorte}: {r.modelo}, {number(r.MAE, 2)} m³/s (n={r.n})' for r in leaders))
    global_audit = metrics.query("etapa == 'Auditoria' and horizonte == @h and recorte == 'Todos'")
    best = global_audit.loc[global_audit.MAE.idxmin()]
    ridge_metric = global_audit.loc[global_audit.modelo.eq('Ridge')].iloc[0]
    st.info(f'Na auditoria de M+{h}, o menor MAE global foi de {number(best.MAE)} m³/s '
            f'({best.modelo}). O Ridge teve MAE de {number(ridge_metric.MAE)} m³/s e NSE de '
            f'{number(ridge_metric.NSE, 3)}.')
    st.download_button('Baixar backtest e períodos de treino (CSV)',
                       backtest.to_csv(index=False).encode('utf-8-sig'), file_name='backtest.csv', mime='text/csv')


def science(frame, sar, daily):
    st.header('Histórico e clima')
    history_tab, correlation_tab, network_tab = st.tabs(['Histórico', 'Correlações', 'Mapa dos postos'])
    with history_tab:
        history(frame, sar, daily)
    with correlation_tab:
        correlations(frame)
    with network_tab:
        figure(network_map(), 'map_network',
               'Localização cadastral dos postos de chuva e vazão usados nas análises. '
               'Cada ponto indica um local de observação. A abrangência da área drenante requer análise da bacia.')


def show_threshold_groups(series, limit):
    months = pd.Series(series.index.month, index=series.index)
    monthly = hydro.threshold_stats(series, limit, months).reindex(range(1, 13)).reset_index(drop=True)
    monthly['Mês'] = MONTHS
    chart = px.bar(monthly, x='Mês', y='Frequência (%)', hover_data=['Abaixo', 'Meses válidos'],
                   range_y=[0, 100], title='Frequência abaixo do limiar por mês do calendário')
    figure(chart, 'threshold_month', 'Cada barra usa os meses válidos daquele mês do calendário. '
           'Código · hidroclima.threshold_stats.')
    dry = pd.Series(np.where(months.isin(DRY), 'Seca (mai–out)', 'Chuvosa (nov–abr)'), index=series.index)
    seasons = pd.Series(np.select([months.isin([12, 1, 2]), months.isin([3, 4, 5]), months.isin([6, 7, 8])],
                                  ['Verão', 'Outono', 'Inverno'], default='Primavera'), index=series.index)
    groups = {
        'Mês do calendário': months.map(dict(enumerate(MONTHS, 1))),
        'Temporada hidrológica': dry,
        'Estação do ano': seasons,
        'Período histórico': hydro.period_groups(series.index),
        'Ano': pd.Series(series.index.year, index=series.index),
    }
    for label, categories in groups.items():
        with st.expander(label, expanded=label == 'Temporada hidrológica'):
            table(hydro.threshold_stats(series, limit, categories).round(1).rename_axis(label).reset_index())
            st.caption('Frequência calculada sobre os meses válidos de cada grupo. Código · hidroclima.threshold_stats.')


def displayed_projections(projections):
    return projections.loc[
        projections.selecionado & projections.alvo.ge(projections.emissao.dt.to_period('M').dt.to_timestamp())
    ].sort_values('alvo')


def show_projection_threshold(projections, limit, history):
    future = displayed_projections(projections)
    labels = [f'{MONTHS[t.month - 1]}/{t.year}' for t in future.alvo]
    chart = go.Figure()
    chart.add_scatter(x=labels, y=future.previsto.to_list(), mode='markers',
                      name='Estimativa selecionada',
                      marker=dict(size=[14, 10], color=['#087eae', '#7461a6']),
                      error_y=dict(type='data', symmetric=False,
                                   array=(future.faixa_sup-future.previsto).to_list(),
                                   arrayminus=(future.previsto-future.faixa_inf).to_list(),
                                   color='#087eae', thickness=2, width=8),
                      hovertemplate='%{x} · %{y:.1f} m³/s<extra></extra>')
    observed = []
    for label, row in zip(labels, future.itertuples()):
        history_at_origin = history.loc[:row.origem].dropna()
        values = history_at_origin[history_at_origin.index.month == row.alvo.month]
        observed.extend(values.tolist())
        chart.add_box(x=[label] * len(values), y=values.tolist(), boxpoints='all', jitter=.35,
                      pointpos=-1.35, name='Histórico do mês-alvo', legendgroup='history',
                      showlegend=label == labels[0], marker_color='#64748b',
                      customdata=values.index.year.tolist(),
                      hovertemplate='%{customdata} · %{y:.1f} m³/s<extra>Histórico SAR</extra>')
        st.write(f'**{label}** · {int(values.lt(limit).sum())} de {len(values)} meses históricos '
                 f'abaixo de {number(limit)} m³/s.')
    if limit is not None:
        chart.add_hline(y=limit, line_dash='dash', line_color='#a45320',
                        annotation_text=f'Limiar · {number(limit)} m³/s',
                        annotation_position='top left')
    chart.update_layout(yaxis_title='Vazão natural (m³/s)', xaxis_title='Mês-alvo', showlegend=True)
    chart.update_xaxes(type='category', categoryorder='array', categoryarray=labels, fixedrange=True)
    ceiling = max([1., limit or 0., *future.faixa_sup, *future.previsto, *observed])
    chart.update_yaxes(range=[0, 1.15*ceiling], fixedrange=True)
    figure(chart, 'future_threshold', 'Cada barra usa os percentis 10 e 90 dos resíduos observado − previsto '
           'da auditoria do mesmo modelo e horizonte, somados à estimativa com piso zero. '
           'Os resíduos reúnem meses distintos. A cobertura para cada mês-alvo permanece indeterminada.')
    for row in future.itertuples():
        relation = 'intercepta' if row.faixa_inf <= limit <= row.faixa_sup else 'fica abaixo de' if limit > row.faixa_sup else 'fica acima de'
        st.write(f'**{month(row.alvo)} · M+{row.horizonte} · {row.modelo}** · '
                 f'{number(row.previsto)} m³/s. Faixa empírica (n={int(row.n_residuos)}) de {number(row.faixa_inf)} a '
                 f'{number(row.faixa_sup)} m³/s {relation} {number(limit)} m³/s.')


def downstream_evidence(hourly, days, limit, day):
    st.subheader('Verificação no ponto de controle 41020002')
    st.caption('A série histórica do posto incluída no projeto termina em outubro de 2006. '
               'Para outubro de 2026, carregue médias horárias da estação de uma fonte identificada.')
    source = st.text_input('Fonte da série e condição de validação', key='downstream_source',
                           placeholder='Órgão, referência da exportação e status de consistência')
    file = st.file_uploader('Importar CSV horário da estação 41020002', type='csv', key='downstream_csv')
    st.download_button('Baixar modelo de CSV', 'estacao,inicio_intervalo,vazao_m3s\n',
                       file_name='modelo_41020002.csv', mime='text/csv')
    st.caption('CSV UTF-8 separado por vírgulas. Use ponto decimal. Informe a média de cada hora '
               'pelo início do intervalo (AAAA-MM-DD HH:MM), em horário de Brasília (UTC−03). '
               'Converta previamente os registros referenciados pelo fim da hora.')
    downstream = None
    if file is not None:
        if not source.strip():
            st.warning('Identifique a fonte e a condição de validação para incluir a série na comparação.')
        else:
            try:
                downstream = load_station_csv(file)
            except (ValueError, pd.errors.ParserError) as error:
                st.error(f'CSV da estação: {error}')
    paired, summary = compare(hourly, days, limit, downstream)
    flagged = summary.loc[summary.diverge]
    complete = int(flagged.intervalos_jusante.eq(12).sum())
    st.write(f'**{len(flagged)} datas sinalizadas pelo ONS · {complete} com cobertura horária completa '
             f'na estação {STATION}.**')
    st.caption('O pareamento usa a mesma hora do relógio e serve à triagem. Uma análise de propagação '
               'exige estimar o tempo de viagem entre os pontos. A origem e a validação declaradas '
               'para arquivos importados devem ser verificadas com o órgão responsável.')
    if not flagged.empty:
        visible = flagged.reset_index()[['dia', 'media_diaria', 'minimo_diurno',
                                        'cobertura_jusante', 'minimo_disponivel_jusante',
                                        'intervalos_jusante_abaixo']]
        table(visible.rename(columns={
            'dia': 'Data', 'media_diaria': 'Média ONS (m³/s)', 'minimo_diurno': 'Mínimo diurno ONS (m³/s)',
            'cobertura_jusante': 'Cobertura 41020002', 'minimo_disponivel_jusante': 'Mínimo disponível 41020002 (m³/s)',
            'intervalos_jusante_abaixo': 'Registros disponíveis abaixo na estação'}))
    selected = paired.loc[paired.dia.eq(day)]
    if selected.vazao_41020002_m3s.notna().any():
        chart = go.Figure()
        for field, name in [('defluencia_ons_m3s', 'Defluência ONS'),
                            ('vazao_41020002_m3s', 'Estação 41020002')]:
            chart.add_scatter(x=selected.inicio.to_list(), y=selected[field].to_list(),
                              mode='lines+markers', name=name, connectgaps=False)
        chart.add_hline(y=limit, line_dash='dot')
        chart.update_layout(title=f'Confronto no dia {day:%d/%m/%Y}', yaxis_title='Vazão (m³/s)')
        figure(chart, 'downstream_comparison', f'Fonte da estação informada pelo usuário: {source.strip()}')
    evidence = paired.loc[paired.dia.isin(flagged.index)].copy()
    evidence['media_diaria_ons_m3s'] = evidence.dia.map(summary.media_diaria)
    evidence['estacao_jusante'] = STATION
    evidence['fonte_jusante'] = source.strip() if downstream is not None else ''
    evidence['fim_intervalo'] = evidence.inicio + pd.Timedelta(hours=1)
    evidence['fuso_horario'] = 'UTC-03:00'
    st.download_button('Baixar evidências das datas sinalizadas (CSV)',
                       evidence.to_csv(index=False).encode('utf-8-sig'),
                       file_name='evidencias_ons_41020002.csv', mime='text/csv')
    if not flagged.empty:
        priority = ', '.join(flagged.index.strftime('%d/%m/%Y'))
        request = (
            f'Solicitamos a série de vazão horária da estação ANA {STATION} e os registros operativos '
            f'da UHE Três Marias para as datas {priority}, com cobertura de 00h às 24h e indicação '
            'de fuso, início/fim de intervalo, lacunas, consistência, revisões e curva-chave aplicável. '
            'Solicitamos também os registros de afluência, armazenamento e restrições operativas '
            'e os atos aplicáveis às datas do recorte. As datas foram selecionadas por triagem '
            f'do ONS a {number(limit)} m³/s, com média diária no patamar ou acima e registro '
            'diurno abaixo do patamar.'
        )
        st.download_button('Baixar minuta de pedido de dados', request.encode('utf-8'),
                           file_name='minuta_pedido_de_dados_41020002.txt', mime='text/plain')
    context = operational_context().loc[day]
    st.write(f'**Contexto operativo de {day:%d/%m/%Y} (ONS diário)**')
    table(context[['val_vazaoafluente', 'val_volumeutilcon', 'val_vazaoturbinada', 'val_vazaovertida']]
          .rename(index={'val_vazaoafluente': 'Afluência (m³/s)', 'val_volumeutilcon': 'Volume útil (%)',
                         'val_vazaoturbinada': 'Vazão turbinada (m³/s)', 'val_vazaovertida': 'Vazão vertida (m³/s)'})
          .to_frame().T.reset_index(drop=True))
    st.caption('Esses indicadores contextualizam a operação. A viabilidade de uma medida depende '
               'também das restrições operativas, regras aplicáveis e condições a jusante.')


def diurnal_flow():
    st.subheader('O que a média diária esconde sobre a defluência?')
    st.write('Compare a média diária oficial do ONS com os registros horários entre 6h e 18h '
             'em outubro de 2026. O limiar inicial de 300 m³/s corresponde ao cenário '
             'associado ao pedido do MPF divulgado em fevereiro de 2026.')
    limit = st.number_input('Limiar do cenário de defluência diurna (m³/s)', min_value=0.0,
                            value=THRESHOLD, step=10.0, key='ons_diurnal_limit')
    hourly, days = analyze(*read_october(), limit)
    eligible = days[days.elegivel]
    below = int(hourly.abaixo.sum())
    cards = st.columns(3)
    cards[0].metric('Registros diurnos abaixo', f'{below} de {len(hourly)}')
    cards[1].metric('Dias com registro abaixo', f'{eligible.horas_abaixo.gt(0).sum()} de {len(eligible)}')
    cards[2].metric('Média diária ≥ limiar e hora diurna abaixo', f'{eligible.diverge.sum()} de {len(eligible)}')
    st.caption(f'Cobertura da comparação · {len(eligible)} de {len(days)} dias. Um dia é elegível '
               'quando tem média diária e os 12 valores horários da janela diurna.')
    if not eligible.empty:
        reference = pd.Timestamp('2026-10-22')
        first = reference if reference in eligible.index else eligible.index[0]
        day = st.selectbox('Dia para explorar', list(eligible.index), index=eligible.index.get_loc(first),
                           format_func=lambda value: value.strftime('%d/%m/%Y'), key='ons_diurnal_day')
        sample = hourly[hourly.dia.eq(day)]
        row = eligible.loc[day]
        st.write(f'**Média diária do ONS:** {number(row.media_diaria)} m³/s · '
                 f'**Menor registro diurno:** {number(row.minimo_diurno)} m³/s · '
                 f'**Intervalos abaixo:** {row.horas_abaixo} de 12')
        chart = go.Figure(go.Bar(x=sample.inicio.dt.strftime('%H:%M').tolist(), y=sample.val_vazaodefluente,
                                 marker_color=np.where(sample.abaixo, '#bd542b', '#087eae'),
                                 name='Defluência horária'))
        chart.add_hline(y=limit, line_dash='dot', annotation_text='Limiar do cenário')
        chart.add_hline(y=eligible.loc[day, 'media_diaria'], line_color='#163e61', line_dash='dash',
                        annotation_text='Média diária oficial', annotation_position='top left')
        chart.update_xaxes(type='category')
        chart.update_yaxes(range=[0, 1.12 * max(1, limit, row.media_diaria, sample.val_vazaodefluente.max())])
        chart.update_layout(title=f'Defluência no dia {day:%d/%m/%Y}',
                            xaxis_title='Hora de início do intervalo', yaxis_title='Defluência (m³/s)')
        figure(chart, 'ons_diurnal', 'Laranja indica registro abaixo do limiar. '
               'Código · defluencia_diurna.analyze.')
    if not eligible.empty:
        overview = go.Figure()
        dates = eligible.index.to_list()
        overview.add_scatter(x=dates, y=eligible.media_diaria.to_list(), mode='lines+markers',
                             name='Média diária ONS', line=dict(color='#163e61', width=2))
        overview.add_scatter(x=dates, y=eligible.minimo_diurno.to_list(), mode='lines+markers',
                             name='Menor registro entre 6h e 18h', line=dict(color='#087eae'))
        flagged = eligible.loc[eligible.diverge]
        overview.add_scatter(x=flagged.index.to_list(), y=flagged.minimo_diurno.to_list(),
                             mode='markers', name='Média ≥ limiar e hora abaixo',
                             marker=dict(color='#b45309', size=10, symbol='diamond'))
        overview.add_hline(y=limit, line_dash='dot', annotation_text=f'Limiar · {number(limit)} m³/s')
        overview.update_layout(title='Em quais dias a média diária ocultou um registro baixo?',
                               xaxis_title='Outubro de 2026', yaxis_title='Defluência (m³/s)')
        overview.update_xaxes(tickformat='%d/%m')
        figure(overview, 'ons_overview', 'Cada losango marca um dia cuja média atingiu o limiar '
               'e que teve pelo menos um registro diurno abaixo dele.')
        st.download_button('Baixar registros horários analisados (CSV)',
                           hourly.to_csv(index=False).encode('utf-8-sig'),
                           file_name='ons_registros_diurnos_outubro_2026.csv', mime='text/csv')
    if not eligible.empty:
        downstream_evidence(hourly, days, limit, day)
    with st.expander('O que verificar para discutir uma medida operativa'):
        st.markdown(
            '1. **Onde e quando ocorreu.** Identifique o dia e o intervalo no CSV e confira o ponto de controle 41020002.\n'
            '2. **Qual critério se aplica.** Confira o ato e eventuais decisões aplicáveis à data. '
            'O pedido divulgado pelo MPF trata de 300 m³/s das 6h às 18h. A resolução consultada '
            'trata de vazão mínima média diária.\n'
            '3. **Qual a viabilidade operacional.** Solicite a série validada a jusante e confronte '
            'afluência, armazenamento e restrições operativas do período.'
        )
        st.markdown('[Pedido divulgado pelo MPF](https://www.mpf.mp.br/o-mpf/unidades/pr-mg/noticias/'
                    'mpf-ajuiza-acao-para-garantir-vazao-minima-do-rio-sao-francisco-em-tres-marias-mg) · '
                    '[Base horária do ONS](https://dados.ons.org.br/dataset/dados_hidrologicos_ho)')
    st.caption('Fonte · ONS, SFTMAR, bases diárias e horárias de outubro/2026. '
               'Os horários do agente são sujeitos a revisão. A análise descreve os registros disponíveis, '
               'com resolução insuficiente para demonstrar continuidade dentro de cada hora. '
               'O cenário reproduz o valor do pedido do MPF. Uma avaliação de conformidade exige verificar o critério aplicável e o ponto de controle.')
    with st.expander('Ver o diagnóstico dos 31 dias'):
        shown = eligible.reset_index()
        shown['dia'] = shown['dia'].dt.strftime('%d/%m/%Y')
        table(shown[['dia', 'media_diaria', 'minimo_diurno', 'horas_abaixo', 'diverge']].rename(columns={
            'dia': 'Data', 'media_diaria': 'Média diária (m³/s)', 'minimo_diurno': 'Mínimo diurno (m³/s)',
            'horas_abaixo': 'Horas abaixo do limiar', 'diverge': 'Média ≥ limiar e hora abaixo'}))
    st.download_button('Baixar comparação diária (CSV)', days.to_csv(index_label='dia').encode('utf-8-sig'),
                       file_name='defluencia_diurna_outubro_2026.csv', mime='text/csv')


def monthly_laboratory(frame, sar):
    st.write('Como a frequência abaixo de uma vazão de referência varia por época do ano e condição hidroclimática?')
    left, right = st.columns(2)
    key = left.selectbox('Vazão analisada', FLOW, format_func=LABELS.get)
    limit = scenario_input(right)
    st.caption('A frequência conta médias mensais estritamente abaixo do limiar. '
               'Q90 e Q95 são propriedades da série selecionada.')
    series = sar[key]
    curve = hydro.permanence(series)
    result = hydro.threshold_stats(series, limit)
    q90, q95 = (hydro.reference_quantile(curve, p) for p in (90, 95))
    for cell, label, value in zip(st.columns(4), ('Meses abaixo', 'Frequência', 'Q90 mensal', 'Q95 mensal'),
                                  (f"{result['abaixo']} de {result['meses']}", f"{number(result['frequencia'])}%",
                                   f'{number(q90)} m³/s', f'{number(q95)} m³/s')):
        cell.metric(label, value)
    window = hydro.coverage(series)
    st.caption(f"Amostra de {month(window['inicio'])} a {month(window['fim'])}. "
               f"Maior sequência abaixo do limiar · {hydro.longest_below(series, limit)} meses.")
    chart = px.line(curve, x='excedencia', y='vazao', range_x=[0, 100],
                    labels={'excedencia': 'Excedência (%)', 'vazao': 'Vazão (m³/s)'},
                    title=f'Curva de permanência · {LABELS[key]}')
    chart.add_hline(y=limit, line_dash='dash', line_color='#a45320', annotation_text=f'Limiar · {number(limit)} m³/s', annotation_position='top left')
    chart.add_scatter(x=[90, 95], y=[q90, q95], mode='markers+text', text=['Q90', 'Q95'],
                      textposition='top left', name='Quantis')
    chart.update_xaxes(tickvals=list(range(0, 101, 20)), fixedrange=True)
    chart.update_yaxes(range=[0, 1.08*max(limit, curve.vazao.max())])
    figure(chart, 'permanence', 'Ordenação decrescente e posição de Weibull. A linha horizontal marca '
           'o limiar. Código · hidroclima.permanence e reference_quantile.')
    show_threshold_groups(series, limit)
    st.subheader('Condições hidroclimáticas nos meses pareados')
    comparison = hydro.climate_comparison(frame, key, limit)
    for col in ('inicio', 'fim'):
        comparison[col] = comparison[col].map(month)
    table(comparison.round({'mediana': 3}).rename(columns={'variavel': 'Variável', 'unidade': 'Unidade',
          'temporada': 'Temporada', 'faixa': 'Faixa de vazão', 'mediana': 'Mediana',
          'inicio': 'Início da amostra sazonal', 'fim': 'Fim da amostra sazonal'}))
    st.caption('Medianas descritivas por par, temporada e faixa. Grupos sem dados exibem n=0. '
               'Código · hidroclima.climate_comparison.')
    st.warning('Vazão natural abaixo do limiar descreve disponibilidade hidrológica. A capacidade de manter '
               'uma defluência exige balanço, armazenamento, regras de operação e restrições a jusante. '
               'As médias mensais tampouco permitem verificar atendimento diário.')



def laboratory(frame, sar):
    st.header('Laboratório interativo de vazões')
    diurnal, monthly, reference = st.tabs(['Defluência diária × horária', 'Histórico mensal', 'Referência climatológica'])
    with diurnal:
        diurnal_flow()
    with monthly:
        monthly_laboratory(frame, sar)
    with reference:
        forecast_page(sar)


def synthesis(frame, sar):
    st.header('Síntese científica')
    st.subheader('Interpretação para o debate de vazões mínimas')
    _, diurnal = analyze(*read_october(), THRESHOLD)
    st.write(f'Em outubro de 2026, {diurnal.diverge.sum()} de {diurnal.elegivel.sum()} dias tinham '
             'média diária oficial de defluência de pelo menos 300 m³/s e algum registro diurno abaixo '
             'desse patamar. O laboratório permite reproduzir o contraste e alterar o limiar.')
    q = sar[FLOW[0]].dropna()
    seasonal = q.groupby(q.index.month).median()
    limit = st.session_state.get('scenario_limit', 150.0)
    chosen = hydro.threshold_stats(q, limit)
    sensitivity = pd.DataFrame([
        {'Limiar (m³/s)': scenario, **hydro.threshold_stats(q, scenario)}
        for scenario in (max(0, limit - 50), limit, limit + 50)
    ]).drop_duplicates().round(1)
    st.subheader('Resultado observado')
    st.write(f'Na série SAR de vazão natural, a mediana mensal vai de {number(seasonal.min())} m³/s '
             f'em {MONTHS[seasonal.idxmin()-1]} a {number(seasonal.max())} m³/s em {MONTHS[seasonal.idxmax()-1]}. '
             f'No cenário de {number(limit)} m³/s, {chosen["abaixo"]} de {chosen["meses"]} meses ficaram abaixo.')
    table(sensitivity.rename(columns={'meses': 'Meses válidos', 'abaixo': 'Abaixo', 'frequencia': 'Frequência (%)'}))
    st.caption('Sensibilidade na série mensal de vazão natural, com o cenário do laboratório e variação de 50 m³/s. '
               'Código · hidroclima.threshold_stats.')
    st.subheader('Associação estatística')
    for label, (x, y, _) in list(PAIRS.items())[:3]:
        result = hydro.correlation(frame, x, y)
        st.write(f'**{label}** · r = {number(result["r"], 3)}, n = {result["n"]}, '
                 f'{month(result["inicio_x"])} a {month(result["fim_x"])}, sem defasagem.')
    st.caption('Pearson em valores mensais brutos. Código · hidroclima.correlation.')
    st.subheader('Previsão experimental')
    _, metrics, projections = load_forecast()
    best = metrics.query("etapa == 'Auditoria' and recorte == 'Todos'").sort_values('MAE')
    best = best.drop_duplicates('horizonte').sort_values('horizonte')
    table(best[['horizonte', 'modelo', 'n', 'MAE', 'NSE']].round(2).rename(
        columns={'modelo': 'Menor MAE na auditoria', 'horizonte': 'Horizonte (meses)'}))
    for projection in displayed_projections(projections).itertuples():
        st.write(f'**{month(projection.alvo)} · M+{projection.horizonte}** · {projection.modelo}: '
                 f'{number(projection.previsto)} m³/s, origem em {month(projection.origem)}. '
                 f'{projection.situacao} na emissão de referência.')
    st.write('O painel permite localizar meses historicamente mais sujeitos a baixa disponibilidade e '
             'medir como a frequência muda com o limiar. A análise de uma liberação mínima requer '
             'considerar o estoque do reservatório, as demandas a jusante e as regras vigentes. '
             'O recorte mensal recente e a chuva pontual limitam a generalização dos resultados.')


def methods():
    st.header('Métodos, fontes e referências')
    manual = ROOT / 'MANUAL_LEITURA_E_METODOLOGIA.md'
    st.markdown(manual.read_text(encoding='utf-8').split('<!-- anexos -->')[0])
    path = DATA / '01_decisao_45_estacoes.csv'
    with st.expander('Inventário das 45 estações ANA'):
        table(pd.read_csv(path, sep=';', dtype={'codigo': str}))
        st.download_button('Baixar inventário CSV', path.read_bytes(), file_name=path.name, mime='text/csv')
        st.caption('Coordenadas cadastrais em graus. Datum e posição dentro da área contribuinte sem '
                   'confirmação em SIG. Código · app.methods.')
    st.download_button('Baixar manual científico', manual.read_bytes(), file_name=manual.name,
                       mime='text/markdown')


frame, sar, daily = load_history()
page = setup()
if page == PAGES[0]:
    context(sar, daily)
elif page == PAGES[1]:
    science(frame, sar, daily)
elif page == PAGES[2]:
    laboratory(frame, sar)
elif page == PAGES[3]:
    synthesis(frame, sar)
else:
    methods()
