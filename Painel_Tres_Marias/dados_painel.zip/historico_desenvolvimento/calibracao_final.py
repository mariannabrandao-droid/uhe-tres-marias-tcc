"""Seleção temporal de hiperparâmetros, com teste externo intocado.
Dados disponíveis no pacote, sem download ou preenchimento artificial.
"""
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from modelagem_temporal import prepare,make_examples,MODELS
ROOT=Path(__file__).resolve().parent
ALPHAS=(1.,10.,100.)

def fit_predict(train, row, cols, alpha):
    model=make_pipeline(StandardScaler(),Ridge(alpha=alpha))
    model.fit(train[cols],train.alvo)
    return max(0.,float(model.predict(pd.DataFrame([row[cols].astype(float)],columns=cols))[0]))

def select_alpha(train,cols, min_inner=24, last_n=6):
    # validação interna: alvos de treino devem preceder a origem da previsão
    origins=list(train.index[-last_n:]); scores={a:[] for a in ALPHAS}
    for origin in origins:
        history=train[(train.data_alvo<origin)&(train.index<origin)]
        if len(history)<min_inner:continue
        row=train.loc[origin]
        for a in ALPHAS:
            p=fit_predict(history,row,cols,a)
            scores[a].append(abs(p-float(row.alvo)))
    good={a:np.mean(s) for a,s in scores.items() if len(s)>=3}
    return min(good,key=good.get) if good else 10.

def run(test_start='2024-01-01',minimum=24):
    d=prepare(); results=[]; future=[]; audits=[]
    for family,cols in MODELS.items():
        for horizon in (1,2):
            ex=make_examples(d,horizon)
            valid=ex.dropna(subset=cols+['alvo'])
            origins=valid[valid.data_alvo>=pd.Timestamp(test_start)].index[-12:]
            for origin in origins:
                train=valid[(valid.data_alvo<origin)&(valid.index<origin)]
                if len(train)<minimum:continue
                alpha=select_alpha(train,cols)
                row=valid.loc[origin]
                preds={'Ridge calibrado':fit_predict(train,row,cols,alpha),
                       'Persistência':float(row.q0),
                       'Climatologia mensal':float(train.loc[train.data_alvo.dt.month==row.data_alvo.month,'alvo'].mean()) if (train.data_alvo.dt.month==row.data_alvo.month).any() else float(train.alvo.mean())}
                for model,pred in preds.items():
                    results.append(dict(familia=family,horizonte=f'M+{horizon}',origem=origin,data_prevista=row.data_alvo,modelo=model,observado=float(row.alvo),previsto=pred,alpha=alpha if model=='Ridge calibrado' else np.nan,n_treino=len(train)))
            ready=ex.dropna(subset=cols)
            if len(ready):
                origin=ready.index.max();train=valid[(valid.data_alvo<=origin)&(valid.index<origin)]
                if len(train)>=minimum:
                    alpha=select_alpha(train,cols);row=ready.loc[origin]
                    future.append(dict(familia=family,horizonte=f'M+{horizon}',origem=origin,data_prevista=row.data_alvo,modelo='Ridge calibrado',previsto_m3s=fit_predict(train,row,cols,alpha),alpha=alpha,n_treino=len(train)))
            audits.append(dict(familia=family,horizonte=f'M+{horizon}',n_pares_completos=len(valid),n_origens_teste=len(origins),ultima_origem=ready.index.max() if len(ready) else pd.NaT,ultimo_alvo_observado=valid.data_alvo.max() if len(valid) else pd.NaT))
    bt=pd.DataFrame(results); ft=pd.DataFrame(future); aud=pd.DataFrame(audits)
    met=[]
    if len(bt):
        for (fam,h,model),g in bt.groupby(['familia','horizonte','modelo']):
            error=g.previsto-g.observado;den=((g.observado-g.observado.mean())**2).sum()
            met.append(dict(familia=fam,horizonte=h,modelo=model,n_teste=len(g),MAE_m3s=error.abs().mean(),RMSE_m3s=np.sqrt(np.mean(error**2)),vies_m3s=error.mean(),NSE=(1-(error**2).sum()/den) if den else np.nan,primeiro_alvo=g.data_prevista.min(),ultimo_alvo=g.data_prevista.max()))
    metrics=pd.DataFrame(met)
    out=ROOT/'resultados_calibracao';out.mkdir(exist_ok=True)
    for name,frame in [('backtest',bt),('metricas',metrics),('projecoes',ft),('auditoria',aud)]:frame.to_csv(out/(name+'.csv'),index=False)
    return bt,metrics,ft,aud

if __name__=='__main__':
    b,m,f,a=run();print(m.to_string(index=False));print('\nPrevisões\n',f.to_string(index=False))
