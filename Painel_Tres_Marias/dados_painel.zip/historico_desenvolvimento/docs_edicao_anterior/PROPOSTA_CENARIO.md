O **filtro histórico** conta intervalos observados abaixo de um limiar e localiza dias em que a média oficial esconde uma hora diurna abaixo do patamar. Alterar o limiar reclassifica os mesmos dados.

Um **cenário operacional** receberia a defluência-alvo em m³/s, período, regra de liberação diurna e noturna, armazenamento inicial e trajetória de afluência. O balanço por intervalo seria:

**V(t+1) = V(t) + Δt × (Qafl − Qturb − Qvert − Qoutros − Qcap) / 10⁶ + (P − E) × A / 10⁹**

V em hm³, Δt em segundos (3.600 por hora), vazões médias em m³/s, P e E em mm por intervalo e A em m². Considerar P e E separadamente somente se a afluência utilizada não incorporar esse termo. Qcap representa captações diretas líquidas, e Qoutros, demais saídas do barramento. A soma de turbinamento, vertimento e demais saídas define a descarga a jusante.

| Requisito | Validação necessária |
|---|---|
| Dados e condições iniciais | Afluência, descargas por rota, cota e armazenamento no mesmo relógio. Curvas cota–área–volume versionadas. Verificação de unidades, fuso, revisões, precipitação e evaporação. |
| Limites físicos | Cotas mínimas e máximas, volume útil e volumes de espera, capacidade de turbinas e vertedouro por nível, rampas e indisponibilidades. Sinalizar alvos inviáveis e documentar o motivo. |
| Regras operativas | Faixa de armazenamento, limites e regras aplicáveis à data, coordenação com o ONS, captações, condições a jusante e usos prioritários. |
| Reprodução antes do cenário | Forçar a saída observada e comparar V e cota calculados com as séries observadas, por hora e por dia. Registrar erro, viés e resíduo acumulado do balanço em diferentes faixas de volume. Validar em período independente e fixar tolerâncias com base na incerteza da medição. |
| Avaliação a jusante | Conferir medições na 41020002, tempo de propagação e contribuições intermediárias. Avaliar nível, qualidade da água e usos com dados específicos para o trecho. |

A defluência-alvo produzirá trajetórias somente após essas verificações. A comparação diária e horária de outubro de 2026 já pode ser reproduzida com o filtro histórico.
