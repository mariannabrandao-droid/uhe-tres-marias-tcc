# Testes da edição de defesa

| Critério | Evidência | Resultado | Pendência |
|---|---|---|---|
| Instalação e início | Ambiente virtual novo, Python 3.12.14, Linux x86_64. Inicialização HTTP em diretório de extração limpo | Dependências instaladas e servidor iniciado. Ver log de instalação e `extracao_limpa.log` | Windows/VS Code documentado. Nenhum comando foi executado no Windows |
| Navegação e gráficos | `interface_reexecucao.log` e `testar_interface_defesa.py` | Cinco páginas abertas com Streamlit AppTest. Gráficos gerados, filtros alterados, estado sem episódios, arquivos de download verificados em memória, propostas e síntese conferidas | Navegação visual Chromium bloqueada pelo ambiente em `socket(): Operation not permitted`. O teste Playwright incluído pode ser executado em máquina local |
| Reprodução independente | `calculos_reexecucao.log` e `testar_calculos_defesa.py` | 16/81 meses SAR, 5 meses seguidos, Pearson 0,565654 com 76 pares a dois meses e ONS 8/31 dias. Testes de lacuna, limiar e alinhamento aprovados | Estações e climatologia são dados históricos de cobertura variável |
| ONS com dados públicos | `ons_reexecucao.log` | Recortes oficiais SFTMAR conferidos. 31 linhas diárias e 744 horárias. O arquivo diário anual mudou de hash desde a extração anterior, com coincidência dos campos da comparação no recorte | Série subdiária recente da estação 41020002 e atos incidentes para análise de conformidade |
| Coerência com Word | Valores centrais comparados ao texto, quatro páginas renderizadas em PDF e revisadas | Roteiro, conclusões e limites em concordância | Inserção no arquivo original depende do Word editável |
| Correção e repetição | Agregação climática recalculada, comparação com legado testada novamente | Bloqueio Total passa a preservar os 12 meses de 1960. ZCAS e bloqueio coincidem no intervalo comum com o legado | Classificação de eventos ZCAS exige catálogo e método validado |

## Comandos de reprodução em Linux

```bash
python -m venv .venv-check
.venv-check/bin/python -m pip install -r requirements.txt
.venv-check/bin/python -m streamlit run app.py --server.headless true --server.port 8518 --browser.gatherUsageStats false
curl --noproxy '*' http://127.0.0.1:8518/_stcore/health
.venv-check/bin/python testar_calculos_defesa.py
.venv-check/bin/python testar_interface_defesa.py
.venv-check/bin/python auditar_ons.py CAMINHO_DIARIO.csv CAMINHO_HORARIO.csv
```

No Windows, use `.\.venv\Scripts\python.exe` no lugar de `.venv-check/bin/python`. Para repetir o teste em navegador, instale Playwright com `python -m pip install playwright==1.62.0` e o Chromium com `python -m playwright install chromium`. Inicie o painel na porta 8518, deixe o servidor rodando e execute `python testar_navegador_defesa.py` em outro terminal. O script admite `TM_APP_URL` e `TM_CHROMIUM` para usar outro endereço ou um Chromium já instalado.
