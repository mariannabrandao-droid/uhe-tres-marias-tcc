"""Validação temporal de previsão mensal: sem vazamento de alvos ou covariáveis futuras.
A emissão é condicionada à última origem com preditores observados, não à data do computador.
"""
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from modelagem_temporal import prepare, make_examples, MODELS
ROOT=Path(__file__).resolve().parent
ALPHAS=(1.,10.,100.)
FAMILIES=('M0','M1')

def fit_predict(train,row,cols,alpha):
    model=make_pipeline(StandardScaler(),Ridge(alpha=alpha))
    model.fit(train[cols],train['alvo'])
    return max(0.,float(model.predict(pd.DataFrame([row[cols]],columns=cols))[0]))

def tune(train,cols,min_train=24):
    # Validação interna por origens temporais: somente alvos disponíveis antes de cada emissão.
    errors={a:[] for a in ALPHAS}
    if len(train)<min_train+4:return 10.
    for pos in range(max(min_train,len(train)-6),len(train)):
        origin=train.index[pos]
        earlier=train.iloc[:pos]
        earlier=earlier[earlier['data_alvo']<origin]
        if len(earlier)<min_train:continue
        row=train.iloc[pos]
        for a in ALPHAS:
            errors[a].append(abs(fit_predict(earlier,row,cols,a)-float(row['alvo'])))
    valid={a:np.mean(err) for a,err in errors.items() if len(err)>=3}
    return min(valid,key=valid.get) if valid else 10.

def run(min_train=24,test_start='2023-01-01'):
    d=prepare();rows=[];future=[];audit=[]
    for h in (1,2):
        ex=make_examples(d,h)
        for fam in FAMILIES:
            cols=MODELS[fam]
            valid=ex.dropna(subset=cols+['alvo']).copy()
            test=valid[valid.data_alvo>=pd.Timestamp(test_start)]
            for origin,row in test.iterrows():
                train=valid[(valid.data_alvo<origin)&(valid.index<origin)]
                if len(train)<min_train:continue
                alpha=tune(train,cols,min_train)
                pred=fit_predict(train,row,cols,alpha)
                # Climatologia mensal: somente meses-alvo historicamente disponíveis antes da origem.
                same=train[train.data_alvo.dt.month==row.data_alvo.month]
                climat=float(same.alvo.mean()) if len(same)>=2 else float(train.alvo.mean())
                for mod,val in [('Ridge',pred),('Persistência',float(row.q0)),('Climatologia',climat)]:
                    rows.append(dict(familia=fam,horizonte=f'M+{h}',modelo=mod,origem=origin,data_prevista=row.data_alvo,observado=float(row.alvo),previsto=val,n_treino=len(train),alpha=alpha if mod=='Ridge' else np.nan))
            ready=ex.loc[ex.index<=d.q.dropna().index.max()].dropna(subset=cols)
            if not ready.empty:
                origin=ready.index.max();row=ready.loc[origin]
                train=valid[(valid.data_alvo<=origin)&(valid.index<origin)]
                if len(train)>=min_train:
                    alpha=tune(train,cols,min_train)
                    pred=fit_predict(train,row,cols,alpha)
                    future.append(dict(familia=fam,horizonte=f'M+{h}',origem=origin,data_prevista=row.data_alvo,previsto_m3s=pred,alpha=alpha,n_treino=len(train),status='Estimativa experimental; verificar data de origem'))
                audit.append(dict(familia=fam,horizonte=f'M+{h}',n_pares_completos=len(valid),ultima_origem=origin,ultima_vazao=d.q.dropna().index.max(),n_treino_emissao=len(train)))
    bt=pd.DataFrame(rows);fu=pd.DataFrame(future);au=pd.DataFrame(audit)
    met=[]
    if not bt.empty:
        for (f,h,m),g in bt.groupby(['familia','horizonte','modelo']):
            err=g.previsto-g.observado;den=((g.observado-g.observado.mean())**2).sum()
            dry=g[g.data_prevista.dt.month.isin([5,6,7,8,9,10])]
            met.append(dict(familia=f,horizonte=h,modelo=m,n=len(g),inicio=g.data_prevista.min(),fim=g.data_prevista.max(),MAE_m3s=err.abs().mean(),RMSE_m3s=np.sqrt(np.mean(err**2)),vies_m3s=err.mean(),NSE=1-(err**2).sum()/den if den>0 else np.nan,MAE_seco_m3s=(dry.previsto-dry.observado).abs().mean() if len(dry) else np.nan))
    mm=pd.DataFrame(met)
    # Comparação pareada: mesmo horizonte, mesmas datas e ambos com previsão Ridge.
    common=[]
    for h in ('M+1','M+2'):
        a=bt[(bt.familia=='M0')&(bt.horizonte==h)&(bt.modelo=='Ridge')]
        b=bt[(bt.familia=='M1')&(bt.horizonte==h)&(bt.modelo=='Ridge')]
        pair=a.merge(b,on=['origem','data_prevista'],suffixes=('_M0','_M1'))
        if len(pair):
            common.append(dict(horizonte=h,n_pares=len(pair),inicio=pair.data_prevista.min(),fim=pair.data_prevista.max(),MAE_M0=(pair.previsto_M0-pair.observado_M0).abs().mean(),MAE_M1=(pair.previsto_M1-pair.observado_M1).abs().mean()))
    return bt,fu,mm,au,pd.DataFrame(common)

def export():
    out=ROOT/'resultados_finais';out.mkdir(exist_ok=True)
    for name,df in zip(('backtest','previsoes','metricas','auditoria','comparacao_pareada'),run()):
        df.to_csv(out/(name+'.csv'),index=False,encoding='utf-8-sig')
    return out
if __name__=='__main__':print('Arquivos gerados em',export())
