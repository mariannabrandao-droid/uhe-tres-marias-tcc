"""Modelagem temporal auditável de vazão natural mensal, com validação expansiva.
M0 = vazão defasada + sazonalidade; M1 = M0 + chuva pontual observada;
M2 = M1 + ZCAS e bloqueio observados. Sem imputação e sem vazamento temporal.
O caderno do professor fundamenta exploração/PCA/cluster, não define divisão treino/teste.
"""
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge

BASE=Path(__file__).resolve().parent.parent/'ANA_Etapa02'/'resultados'/'13_matriz_recente_datamining.csv'
MODELS={'M0':['q0','q1','q2','q3','q6','q12','seno','cosseno'],
        'M1':['q0','q1','q2','q3','q6','q12','seno','cosseno','chuva0','chuva1'],
        'M2':['q0','q1','q2','q3','q6','q12','seno','cosseno','chuva0','chuva1','zcas0','bloq0']}

def prepare(path=BASE):
    d=pd.read_csv(path,sep=';',parse_dates=['data']).sort_values('data').set_index('data').asfreq('MS')
    for k in ['vazao_natural_m3s','chuva_andrequice_mm','SACZ_AB','dias_bloqueio_total']:
        d[k]=pd.to_numeric(d[k],errors='coerce')
    cov=pd.to_numeric(d['vazao_natural_m3s_cobertura'],errors='coerce')
    d['q']=d['vazao_natural_m3s'].where(cov>=0.999999)
    d['chuva']=d['chuva_andrequice_mm'];d['zcas']=d['SACZ_AB'];d['bloq']=d['dias_bloqueio_total']
    for lag in [0,1,2,3,6,12]:d[f'q{lag}']=d.q.shift(lag)
    for lag in [0,1]:d[f'chuva{lag}']=d.chuva.shift(lag)
    d['zcas0']=d.zcas;d['bloq0']=d.bloq
    return d

def make_examples(d,h):
    z=d.copy();target_dates=z.index+pd.DateOffset(months=h)
    z['data_alvo']=target_dates
    z['alvo']=pd.Series(d.q.reindex(target_dates).to_numpy(),index=z.index)
    z['seno']=np.sin(2*np.pi*pd.DatetimeIndex(target_dates).month/12)
    z['cosseno']=np.cos(2*np.pi*pd.DatetimeIndex(target_dates).month/12)
    return z

def train_and_backtest(d,minimum=24,test_start='2024-01-01'):
    results=[]; forecasts=[];audit=[]
    last=d.q.dropna().index.max()
    for h in [1,2,3]:
        ex=make_examples(d,h)
        for family,cols in MODELS.items():
            valid=ex.dropna(subset=cols+['alvo'])
            candidates=valid[valid.data_alvo>=pd.Timestamp(test_start)]
            for origin,row in candidates.iterrows():
                # alvo do treinamento anterior à origem de emissão, não apenas anterior ao alvo testado
                train=valid[(valid.data_alvo<origin)&(valid.index<origin)]
                if len(train)<minimum:continue
                mdl=make_pipeline(StandardScaler(),Ridge(alpha=10.0))
                mdl.fit(train[cols],train.alvo)
                pred=max(0.,float(mdl.predict(row[cols].to_frame().T)[0]))
                for name,value in [('Ridge',pred),('Persistência',float(row.q0))]:
                    results.append(dict(familia=family,horizonte=f'M+{h}',modelo=name,origem=origin,data_prevista=row.data_alvo,observado=float(row.alvo),previsto=value,n_treino=len(train)))
            # Previsão emitida somente com a última origem com todos os preditores disponíveis.
            # Não chamar de previsão atual se a origem for antiga.
            ready=ex.loc[(ex.index<=last)].dropna(subset=cols)
            if ready.empty:continue
            origin=ready.index.max(); row=ready.loc[origin]
            train=valid[(valid.data_alvo<=origin)&(valid.index<origin)]
            if len(train)<minimum:continue
            mdl=make_pipeline(StandardScaler(),Ridge(alpha=10.0)).fit(train[cols],train.alvo)
            for name,value in [('Ridge',max(0.,float(mdl.predict(row[cols].to_frame().T)[0]))),('Persistência',float(row.q0))]:
                forecasts.append(dict(familia=family,horizonte=f'M+{h}',modelo=name,origem=origin,data_prevista=row.data_alvo,previsto=value,n_treino=len(train),ultima_observacao_vazao=last))
            audit.append(dict(familia=family,horizonte=f'M+{h}',n_pares_completos=len(valid),n_teste=len(candidates),ultima_origem_com_preditores=origin,ultima_vazao_observada=last,atributos=', '.join(cols)))
    back=pd.DataFrame(results); future=pd.DataFrame(forecasts); aud=pd.DataFrame(audit)
    if len(back):
        back['erro']=back.previsto-back.observado
        back['erro_abs']=back.erro.abs()
        back['erro_quadrado']=back.erro**2
        metrics=[]
        for (f,h,m),g in back.groupby(['familia','horizonte','modelo']):
            den=((g.observado-g.observado.mean())**2).sum()
            metrics.append(dict(familia=f,horizonte=h,modelo=m,n_teste=len(g),inicio=g.data_prevista.min(),fim=g.data_prevista.max(),MAE_m3s=g.erro_abs.mean(),RMSE_m3s=np.sqrt(g.erro_quadrado.mean()),Vies_m3s=g.erro.mean(),NSE=1-g.erro_quadrado.sum()/den if den>0 else np.nan))
        met=pd.DataFrame(metrics)
    else:met=pd.DataFrame()
    return back,future,met,aud

def balance_simplified(q_in,q_out,days):
    """Variação de volume (hm³), sem outros termos do balanço; não representa operação real."""
    return (np.asarray(q_in)-np.asarray(q_out))*86400*np.asarray(days)/1e6

def forecast_live(d, minimum=24):
    """Projeções a partir da última origem válida, com treino anterior à emissão.
    Não extrapola preditores ausentes e não faz atualização de dados externa.
    """
    rows=[]
    for h in [1,2,3]:
        ex=make_examples(d,h)
        for family,cols in MODELS.items():
            valid=ex.dropna(subset=cols+['alvo'])
            ready=ex.dropna(subset=cols)
            if ready.empty: continue
            origin=ready.index.max()
            train=valid[(valid.data_alvo<=origin)&(valid.index<origin)]
            if len(train)<minimum:continue
            mdl=make_pipeline(StandardScaler(),Ridge(alpha=10.)).fit(train[cols],train.alvo)
            row=ready.loc[origin]
            y=max(0.,float(mdl.predict(row[cols].to_frame().T)[0]))
            for model, pred in [('Ridge',y),('Persistência',float(row.q0))]:
                rows.append(dict(familia=family,horizonte=f'M+{h}',modelo=model,
                    origem=origin,data_prevista=row.data_alvo,previsto_m3s=pred,
                    n_treino=len(train),atualidade='Origem observada; não necessariamente atual'))
    return pd.DataFrame(rows)

if __name__=='__main__':
    out=Path(__file__).resolve().parent/'resultados_modelagem';out.mkdir(exist_ok=True)
    d=prepare(); back,future,met,aud=train_and_backtest(d)
    for name,frame in [('backtest_temporal',back),('previsoes_condicionais',future),('metricas_temporais',met),('auditoria_modelos',aud)]:frame.to_csv(out/(name+'.csv'),index=False)
    print('Backtest',len(back),'previsões condicionais',len(future));print(met.to_string(index=False))

def scenario_at_origin(d,family='M1',horizon=1,delta_rain_pct=0.,zcas_factor=1.,blocking_delta=0.):
    """Experimento condicional, mantendo atributos observados na origem fixa.
    Mudanças aplicadas somente às covariáveis, sem retroalimentar a vazão observada.
    Não constitui previsão meteorológica, causal ou operacional.
    """
    cols=MODELS[family];ex=make_examples(d,horizon)
    ready=ex.dropna(subset=cols)
    if ready.empty:return None
    origin=ready.index.max();row=ready.loc[origin]
    train=ex.dropna(subset=cols+['alvo'])
    train=train[(train.data_alvo<=origin)&(train.index<origin)]
    if len(train)<24:return None
    model=make_pipeline(StandardScaler(),Ridge(alpha=10.)).fit(train[cols],train.alvo)
    ref=row[cols].astype(float).copy();changed=ref.copy()
    if family in ['M1','M2']:
        for key in ['chuva0','chuva1']:changed[key]=max(0.,changed[key]*(1+delta_rain_pct/100))
    if family=='M2':
        changed['zcas0']=max(0.,changed['zcas0']*zcas_factor)
        changed['bloq0']=max(0.,changed['bloq0']+blocking_delta)
    baseline=max(0.,float(model.predict(pd.DataFrame([ref],columns=cols))[0]))
    altered=max(0.,float(model.predict(pd.DataFrame([changed],columns=cols))[0]))
    return dict(origem=origin,alvo=row.data_alvo,base=baseline,cenario=altered,delta=altered-baseline,n_treino=len(train),atributos=cols)
