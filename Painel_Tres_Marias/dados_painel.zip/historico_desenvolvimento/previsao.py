"""Protocolo final M0, baseado nos atributos e na calibração da versão anterior."""
import numpy as np
import pandas as pd

from calibracao_final import fit_predict, select_alpha
from hidroclima import DATA, DRY, ISSUE, ROOT, complete_sar
from modelagem_temporal import MODELS, make_examples, prepare

MODELS_FINAL = ('Persistência', 'Climatologia', 'Ridge')
FEATURES = MODELS['M0']
MINIMUM = 24
DEVELOPMENT = pd.Timestamp('2023-01-01')
AUDIT = pd.Timestamp('2025-01-01')
LOW = 150.0


def training_pairs(valid, origin):
    return valid.loc[valid.data_alvo.lt(origin)]


def forecasts(train, row, known):
    alpha = select_alpha(train, FEATURES)
    same_month = known.loc[known.index.month == row.data_alvo.month]
    return {
        'Persistência': float(row.q0),
        'Climatologia': float(same_month.mean()),
        'Ridge': fit_predict(train, row, FEATURES, alpha),
    }, alpha


def metrics(backtest):
    rows = []
    for (split, horizon, model), group in backtest.groupby(['etapa', 'horizonte', 'modelo']):
        dry = group.alvo.dt.month.isin(DRY)
        for label, sample in (
            ('Todos', group), ('Seca (mai–out)', group[dry]),
            ('Baixa (<150 m³/s)', group[group.observado.lt(LOW)]),
        ):
            error = sample.previsto - sample.observado
            sst = ((sample.observado - sample.observado.mean()) ** 2).sum()
            rows.append(dict(etapa=split, horizonte=horizon, modelo=model, recorte=label,
                             n=len(sample), MAE=error.abs().mean(), RMSE=np.sqrt(error.pow(2).mean()),
                             vies=error.mean(), NSE=1-error.pow(2).sum()/sst if sst > 0 else np.nan))
    return pd.DataFrame(rows)


def choose(metrics_frame, horizon):
    selection = metrics_frame.query("etapa == 'Seleção' and horizonte == @horizon")
    wide = selection.pivot(index='modelo', columns='recorte', values='MAE').reindex(MODELS_FINAL)
    counts = selection.groupby('recorte').n.min()
    subsets = ['Todos', 'Seca (mai–out)']
    if counts.get('Baixa (<150 m³/s)', 0) >= 5:
        subsets.append('Baixa (<150 m³/s)')
    # Média de posições com o mesmo peso por recorte. Empates favorecem o menor MAE global.
    score = wide[subsets].rank(axis=0, method='min').mean(axis=1)
    return min(MODELS_FINAL, key=lambda name: (score[name], wide.at[name, 'Todos']))


def run():
    data = prepare()
    sar_q = complete_sar().vazao_natural_m3s
    np.testing.assert_allclose(data.q.reindex(sar_q.index), sar_q, equal_nan=True)
    cutoff = (ISSUE.to_period('M') - 1).to_timestamp()
    data = data.loc[:cutoff]
    q = data.q.dropna()
    origin_final = data.dropna(subset=[key for key in FEATURES if key not in ('seno', 'cosseno')]).index.max()
    rows, future = [], []
    for h in (1, 2, 3):
        examples = make_examples(data, h)
        valid = examples.dropna(subset=FEATURES + ['alvo'])
        for origin, row in valid[valid.data_alvo.ge(DEVELOPMENT)].iterrows():
            train = training_pairs(valid, origin)
            if len(train) < MINIMUM:
                continue
            # A seleção encerra antes da primeira origem auditada, inclusive para M+3.
            first_audit_origin = AUDIT - pd.DateOffset(months=h)
            if first_audit_origin <= row.data_alvo < AUDIT:
                continue
            split = 'Seleção' if row.data_alvo < AUDIT else 'Auditoria'
            preds, alpha = forecasts(train, row, q.loc[:origin])
            for model, pred in preds.items():
                rows.append(dict(etapa=split, horizonte=h, origem=origin, alvo=row.data_alvo,
                                 modelo=model, observado=row.alvo, previsto=pred,
                                 alpha=alpha if model == 'Ridge' else np.nan,
                                 treino_inicio=train.data_alvo.min(), treino_fim=train.data_alvo.max(),
                                 n_treino=len(train), climatologia_fim=origin))
        row = examples.loc[origin_final]
        train = training_pairs(valid, origin_final)
        preds, alpha = forecasts(train, row, q.loc[:origin_final])
        for model, pred in preds.items():
            future.append(dict(horizonte=h, origem=origin_final, alvo=row.data_alvo, emissao=ISSUE,
                               modelo=model, previsto=pred, alpha=alpha if model == 'Ridge' else np.nan,
                               treino_inicio=train.data_alvo.min(), treino_fim=train.data_alvo.max(),
                               n_treino=len(train), ultimo_observado=q.index.max(),
                               situacao=('Futuro' if row.data_alvo > ISSUE else
                                         'Mês em curso' if row.data_alvo.month == ISSUE.month else
                                         'Mês encerrado sem observação completa')))
    backtest = pd.DataFrame(rows)
    summary = metrics(backtest)
    projection = pd.DataFrame(future)
    projection['selecionado'] = projection.apply(lambda r: r.modelo == choose(summary, r.horizonte), axis=1)
    for i, row in projection.iterrows():
        audit = backtest.query("etapa == 'Auditoria' and horizonte == @row.horizonte and modelo == @row.modelo")
        residuals = audit.observado - audit.previsto
        low, high = residuals.quantile([.1, .9])
        projection.loc[i, ['faixa_inf', 'faixa_sup', 'n_residuos']] = [
            max(0, row.previsto + low), max(0, row.previsto + high), len(residuals)]
    return backtest, summary, projection


if __name__ == '__main__':
    out = ROOT / 'historico_desenvolvimento' / 'resultados_entrega'
    out.mkdir(exist_ok=True)
    for name, table in zip(('backtest', 'metricas', 'projecoes'), run()):
        table.to_csv(out / f'{name}.csv', index=False, encoding='utf-8-sig')
        if name == 'projecoes':
            print(table.to_string(index=False))
