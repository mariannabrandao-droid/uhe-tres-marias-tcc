"""Exercita a interface em Chromium com um servidor Streamlit em execução."""
import os

from playwright.sync_api import expect, sync_playwright

URL = os.environ.get('TM_APP_URL', 'http://127.0.0.1:8518')


def main():
    with sync_playwright() as playwright:
        binary = os.environ.get('TM_CHROMIUM')
        browser = playwright.chromium.launch(executable_path=binary, args=['--no-sandbox'])
        page = browser.new_page(viewport={'width': 1440, 'height': 1000}, accept_downloads=True)
        page.set_default_timeout(30000)
        page.goto(URL)

        def navigate(label, heading):
            page.get_by_text(label, exact=True).click()
            expect(page.get_by_role('heading', name=heading, exact=True)).to_be_visible()
            expect(page.get_by_test_id('stException')).to_have_count(0)
            print(f'Página conferida: {heading}', flush=True)

        navigate('01 · Usina, operação e vazão mínima', 'Três Marias em contexto')
        expect(page.get_by_test_id('stPlotlyChart').first).to_be_visible()
        expect(page.get_by_role('heading', name='O que o Ministério Público pediu')).to_be_visible()
        navigate('02 · Histórico, ZCAS e bloqueios', 'Histórico hidrológico, ZCAS e bloqueios')
        page.get_by_role('tab', name='Sequências de baixa vazão').click()
        expect(page.get_by_text('16 de 81 meses completos abaixo do limiar.')).to_be_visible()
        field = page.get_by_role('spinbutton', name='Limiar histórico de vazão natural mensal (m³/s)')
        field.fill('0')
        field.press('Enter')
        expect(page.get_by_text('Nenhuma sequência abaixo do limiar neste recorte.')).to_be_visible()
        page.get_by_role('tab', name='Associações climáticas').click()
        expect(page.get_by_text('r = 0,671', exact=False).first).to_be_visible()
        with page.expect_download() as item:
            page.get_by_role('button', name='Baixar associações (CSV)').click()
        assert 'Sensibilidade' in item.value.path().read_text(encoding='utf-8-sig')
        page.get_by_text('Chuva e vazão', exact=True).click()
        expect(page.get_by_text('Chuva pontual e a agregação mensal', exact=False).first).to_be_visible()
        navigate('03 · Antecipação de baixa vazão', 'Proposta para antecipar baixa vazão')
        expect(page.get_by_text('Em proposta', exact=False).first).to_be_visible()
        expect(page.get_by_test_id('stPlotlyChart')).to_have_count(0)
        navigate('04 · Defluência histórica e cenários', 'Defluência histórica e proposta de cenário')
        expect(page.get_by_text('8 de 31', exact=True).first).to_be_visible()
        expect(page.get_by_text('164,0 m³/s', exact=False).first).to_be_visible()
        with page.expect_download() as item:
            page.get_by_role('button', name='Baixar comparação diária (CSV)').click()
        assert len(item.value.path().read_text(encoding='utf-8-sig').splitlines()) == 32
        for label in ['Baixar registros horários analisados (CSV)', 'Baixar modelo de CSV',
                      'Baixar evidências das datas sinalizadas (CSV)', 'Baixar minuta de pedido de dados']:
            with page.expect_download() as item:
                page.get_by_role('button', name=label, exact=True).click()
            assert item.value.path().stat().st_size > 0
        field = page.get_by_role('spinbutton', name='Limiar do filtro histórico de defluência diurna (m³/s)')
        field.fill('0')
        field.press('Enter')
        expect(page.get_by_text('0 de 372', exact=True)).to_be_visible()
        page.get_by_role('tab', name='Cenário operacional em proposta').click()
        expect(page.get_by_text('simulação condicionada', exact=False).first).to_be_visible()
        navigate('05 · Síntese e rastreabilidade', 'Síntese técnica e rastreabilidade')
        expect(page.get_by_text('8 de 31 dias', exact=False).first).to_be_visible()
        page.get_by_text('Fontes, fórmulas e matriz de rastreabilidade', exact=True).click()
        with page.expect_download() as item:
            page.get_by_role('button', name='Baixar rastreabilidade').click()
        assert 'Pearson' in item.value.path().read_text(encoding='utf-8')
        page.get_by_text('Inventário ANA e cobertura das séries', exact=True).click()
        for name in ['01_decisao_45_estacoes.csv', 'inventario_series.csv']:
            with page.expect_download() as item:
                page.get_by_role('button', name=f'Baixar {name}', exact=True).click()
            assert item.value.path().stat().st_size > 0
        print('Filtros, estado vazio, gráficos, propostas e downloads conferidos.', flush=True)
        browser.close()


if __name__ == '__main__':
    main()
